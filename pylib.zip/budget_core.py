#!/usr/bin/env python3
"""
Budget Tracker - core logic (no user interface).
-------------------------------------------------
Parses monthly bank statement PDFs (Portable Document Format) from Swedbank and
Revolut, categorizes every transaction and creates / updates the Excel report.
Used by budget_gui.py through update_report() and load/save_settings().

Your data lives in Budget_data.json next to the report (and, encrypted, on GitHub for the iPhone).
Budget.xlsx is a report rebuilt from it after every change - change things in the app, not in Excel.
Already-imported transactions are never duplicated.

Workbook (rebuilt):
  Summary       monthly totals per category (Excel formulas, live)
  Compare       a month against the month before and the average
  Balances      money in each account at the end of each month
  Places        subscriptions and food places per month
  Transactions  every transaction
  Rules         your keyword -> category rules (made in the app)
"""

import json
import os
import re
import shutil
import threading
import time
import unicodedata
from collections import Counter, defaultdict
from contextlib import contextmanager
from functools import lru_cache
from datetime import date, datetime, timedelta
from io import BytesIO
from pathlib import Path

import pdfplumber

import budget_merchants as merchants
from openpyxl import Workbook, load_workbook
from openpyxl.comments import Comment
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from openpyxl.utils import get_column_letter
from openpyxl.worksheet.datavalidation import DataValidation

REPORT_NAME = "Budget.xlsx"
BACKUP_NAME = "Budget_backup.xlsx"     # single backup written by earlier versions
BACKUP_DIR = "Backups"                  # folder next to the report with the last versions
KEEP_BACKUPS = 20

TYPES = ["Expense", "Income", "Savings", "Investment", "Transfer"]
TX_HEADERS = ["Date", "Month", "Description", "Place", "Amount", "Category",
              "Type", "Note", "Source file", "Bank", "Auto category"]
TXC = {h: get_column_letter(i + 1) for i, h in enumerate(TX_HEADERS)}   # column letters

# Summary column groups: (type, group label, shown negated, pinned columns, colours)
# Pinned columns are always shown; any other category gets its own column
# automatically as soon as a transaction uses it.
GROUPS = [
    ("Income", "INCOME", False, ["Salary", "Family"], ("548235", "E2EFDA")),
    ("Expense", "EXPENSES", True, ["Car", "Market", "Eating out", "Clothes"], ("C65911", "FCE4D6")),
    ("Savings", "SAVINGS", True, ["Savings"], ("2F75B5", "DDEBF7")),
    ("Investment", "INVESTMENTS", True, ["Investments"], ("7030A0", "E4DFEC")),
]
TOTALS_COLORS = ("404040", "EDEDED")

# Categories listed place-by-place on the Places sheet
PLACES_CATEGORIES = [("Subscriptions", "D9D9D9"), ("Market", "E2EFDA"), ("Eating out", "FCE4D6")]

# App settings (saved by the app in settings.json)
DEFAULT_SETTINGS = {
    "my_name": "",
    "family": [],
    "investments": "",
    "report": "",                      # full path of Budget.xlsx; empty = next to the app
    "merged": {},                      # {category: category it was merged into}
    "sync": {},                        # iPhone app: GitHub token, gist, passphrase (kept between starts!)
}

# Built-in categorization rules: (keyword, category, type). They live here in the code,
# not in Budget.xlsx, so app updates bring new rules without touching your file.
# First match wins, so specific rules must be above general ones.
# Keywords match whole words ("bolt" is not "Bolton"); a trailing * matches the start
# of a word, for Lithuanian stems ("kavin*" = kavinė, kavinės ...).
# Expense rules only take money going out (and refunds); Income rules only money coming in.
# <...> rows are filled from the app settings (Settings button in the app).
# Category "Other" is reserved: unmatched spending and unmatched income land there.
DEFAULT_RULES = [
    # --- own accounts and people (from app settings) ---
    ("transfer between own accounts", "Savings", "Savings"),
    ("easy saver", "Savings", "Savings"),
    ("instant access savings", "Savings", "Savings"),
    ("savings vault", "Savings", "Savings"),
    ("taupykl*", "Savings", "Savings"),
    ("<INVESTMENT ACCOUNT>", "Investments", "Investment"),
    ("investment*", "Investments", "Investment"),
    ("investic*", "Investments", "Investment"),
    ("revolut securities", "Investments", "Investment"),
    ("interactive brokers", "Investments", "Investment"),
    ("ibkr", "Investments", "Investment"),
    ("freedom finance", "Investments", "Investment"),
    ("cmafreedom", "Investments", "Investment"),
    ("withdrawal of clients funds", "Investments", "Investment"),
    ("brokerage", "Investments", "Investment"),
    ("revolut digital assets", "Investments", "Investment"),
    ("purchase of btc", "Investments", "Investment"),
    ("Netta Solutions", "Salary", "Income"),
    ("atlyginim*", "Salary", "Income"),
    ("darbo užmokest*", "Salary", "Income"),
    ("salary", "Salary", "Income"),
    ("<FAMILY>", "Family", "Income"),
    ("<MY NAME>", "Internal transfer", "Transfer"),
    ("top up", "Internal transfer", "Transfer"),
    ("papildym*", "Internal transfer", "Transfer"),
    ("exchanged", "Internal transfer", "Transfer"),
    # --- expenses ---
    ("circle k", "Car", "Expense"),
    ("viada", "Car", "Expense"),
    ("neste", "Car", "Expense"),
    ("orlen", "Car", "Expense"),
    ("baltic petroleum", "Car", "Expense"),
    ("emsi", "Car", "Expense"),
    ("jozita", "Car", "Expense"),
    ("parking", "Car", "Expense"),
    ("parkav*", "Car", "Expense"),
    ("unipark", "Car", "Expense"),
    ("plovykl*", "Car", "Expense"),
    ("autoserv*", "Car", "Expense"),
    ("padang*", "Car", "Expense"),
    ("regitra", "Car", "Expense"),
    ("maxima", "Market", "Expense"),
    ("barbora", "Market", "Expense"),
    ("iki", "Market", "Expense"),
    ("rimi", "Market", "Expense"),
    ("lidl", "Market", "Expense"),
    ("norfa", "Market", "Expense"),
    ("aibė", "Market", "Expense"),
    ("šilas", "Market", "Expense"),
    ("promo cash", "Market", "Expense"),
    ("turg*", "Market", "Expense"),
    ("bolt food", "Eating out", "Expense"),
    ("uber eats", "Eating out", "Expense"),
    ("wolt", "Eating out", "Expense"),
    ("mcdonald*", "Eating out", "Expense"),
    ("hesburger", "Eating out", "Expense"),
    ("kfc", "Eating out", "Expense"),
    ("čili", "Eating out", "Expense"),
    ("vapiano", "Eating out", "Expense"),
    ("caif", "Eating out", "Expense"),
    ("vero cafe", "Eating out", "Expense"),
    ("coffee", "Eating out", "Expense"),
    ("kavin*", "Eating out", "Expense"),
    ("restoran*", "Eating out", "Expense"),
    ("picer*", "Eating out", "Expense"),
    ("pizza", "Eating out", "Expense"),
    ("sushi", "Eating out", "Expense"),
    ("kebab*", "Eating out", "Expense"),
    ("doner*", "Eating out", "Expense"),
    ("kaukita", "Eating out", "Expense"),
    ("zara", "Clothes", "Expense"),
    ("h&m", "Clothes", "Expense"),
    ("reserved", "Clothes", "Expense"),
    ("cropp", "Clothes", "Expense"),
    ("sinsay", "Clothes", "Expense"),
    ("mohito", "Clothes", "Expense"),
    ("bershka", "Clothes", "Expense"),
    ("pull&bear", "Clothes", "Expense"),
    ("mango", "Clothes", "Expense"),
    ("lindex", "Clothes", "Expense"),
    ("new yorker", "Clothes", "Expense"),
    ("zalando", "Clothes", "Expense"),
    ("about you", "Clothes", "Expense"),
    ("humana", "Clothes", "Expense"),
    ("nike", "Clothes", "Expense"),
    ("adidas", "Clothes", "Expense"),
    ("bolt", "Transport", "Expense"),
    ("uber", "Transport", "Expense"),
    ("trafi", "Transport", "Expense"),
    ("žiogas", "Transport", "Expense"),
    ("kauno autobusai", "Transport", "Expense"),
    ("m ticket", "Transport", "Expense"),
    ("ltg", "Transport", "Expense"),
    ("citybee", "Transport", "Expense"),
    ("ignitis", "Housing & utilities", "Expense"),
    ("enefit", "Housing & utilities", "Expense"),
    ("elektrum", "Housing & utilities", "Expense"),
    ("kauno energija", "Housing & utilities", "Expense"),
    ("kauno vandenys", "Housing & utilities", "Expense"),
    ("telia", "Housing & utilities", "Expense"),
    ("tele2", "Housing & utilities", "Expense"),
    ("bitė", "Housing & utilities", "Expense"),
    ("uab init", "Housing & utilities", "Expense"),
    ("nuom*", "Housing & utilities", "Expense"),
    ("rent", "Housing & utilities", "Expense"),
    ("būsto", "Housing & utilities", "Expense"),
    ("draudim*", "Insurance", "Expense"),
    ("insurance", "Insurance", "Expense"),
    ("vaistin*", "Health", "Expense"),
    ("eurovaistin*", "Health", "Expense"),
    ("camelia", "Health", "Expense"),
    ("benu", "Health", "Expense"),
    ("gintarinė", "Health", "Expense"),
    ("klinik*", "Health", "Expense"),
    ("odontolog*", "Health", "Expense"),
    ("lemon gym", "Sport", "Expense"),
    ("impuls", "Sport", "Expense"),
    ("baseinas", "Sport", "Expense"),
    ("sportland", "Sport", "Expense"),
    ("decathlon", "Sport", "Expense"),
    ("plaukimo", "Sport", "Expense"),
    ("sportas", "Sport", "Expense"),
    ("senukai", "Shopping", "Expense"),
    ("ermitažas", "Shopping", "Expense"),
    ("ikea", "Shopping", "Expense"),
    ("pigu", "Shopping", "Expense"),
    ("varle", "Shopping", "Expense"),
    ("amazon prime", "Subscriptions", "Expense"),
    ("prime video", "Subscriptions", "Expense"),
    ("amazon", "Shopping", "Expense"),
    ("temu", "Shopping", "Expense"),
    ("aliexpress", "Shopping", "Expense"),
    ("jysk", "Shopping", "Expense"),
    ("topo centras", "Shopping", "Expense"),
    ("euronics", "Shopping", "Expense"),
    ("pepco", "Shopping", "Expense"),
    ("sportano", "Shopping", "Expense"),
    ("priedaitelefonams", "Shopping", "Expense"),
    ("telestart", "Shopping", "Expense"),
    ("ebay", "Shopping", "Expense"),
    ("shein", "Shopping", "Expense"),
    ("notino", "Shopping", "Expense"),
    ("skytech", "Shopping", "Expense"),
    ("kilobaitas", "Shopping", "Expense"),
    ("bigbox", "Shopping", "Expense"),
    ("elektromarkt", "Shopping", "Expense"),
    ("1a lt", "Shopping", "Expense"),
    ("spotify", "Subscriptions", "Expense"),
    ("netflix", "Subscriptions", "Expense"),
    ("youtube*", "Subscriptions", "Expense"),
    ("google", "Subscriptions", "Expense"),
    ("apple", "Subscriptions", "Expense"),
    ("microsoft*", "Subscriptions", "Expense"),
    ("openai", "Subscriptions", "Expense"),
    ("anthropic", "Subscriptions", "Expense"),
    ("claude", "Subscriptions", "Expense"),
    ("disney*", "Subscriptions", "Expense"),
    ("go3", "Subscriptions", "Expense"),
    ("ryanair", "Travel", "Expense"),
    ("wizz*", "Travel", "Expense"),
    ("airbaltic", "Travel", "Expense"),
    ("booking", "Travel", "Expense"),
    ("airbnb", "Travel", "Expense"),
    ("hotel*", "Travel", "Expense"),
    ("forum cinemas", "Entertainment", "Expense"),
    ("cinamon*", "Entertainment", "Expense"),
    ("tiketa", "Entertainment", "Expense"),
    ("bilietai", "Entertainment", "Expense"),
    ("steam*", "Entertainment", "Expense"),
    ("playstation", "Entertainment", "Expense"),
    ("bowling", "Entertainment", "Expense"),
    ("apzvalg*", "Entertainment", "Expense"),
    ("bouling*", "Entertainment", "Expense"),
    ("pegasas", "Books & education", "Expense"),
    ("knyg*", "Books & education", "Expense"),
    ("humanitas", "Books & education", "Expense"),
    ("udemy", "Books & education", "Expense"),
    ("coursera", "Books & education", "Expense"),
    ("atm", "Cash", "Expense"),
    ("bankomat*", "Cash", "Expense"),
    ("cash withdrawal", "Cash", "Expense"),
    ("grynųjų", "Cash", "Expense"),
    ("komisin*", "Bank fees", "Expense"),
    ("aptarnavim*", "Bank fees", "Expense"),
    ("plan fee", "Bank fees", "Expense"),
    ("banko mokest*", "Bank fees", "Expense"),
    ("paslaugu mokest*", "Bank fees", "Expense"),
    ("administravimo mokest*", "Bank fees", "Expense"),
    ("įkainis", "Bank fees", "Expense"),
    ("kortelės išdavim*", "Bank fees", "Expense"),
]

RULES_HELP = [
    "YOUR RULES",
    "Add a row to put a place or payment into a category, e.g.   Kaukita | Eating out | Expense",
    "Your rules are checked first, then the app's built-in ones (Maxima, Lidl, Bolt, Spotify, bank fees ...),",
    "   so a row here can also override a built-in rule. App updates never change this sheet.",
    "Keyword: text from the payment description. Case, Lithuanian letters, spaces and punctuation don't matter.",
    "Type: Expense, Income, Savings, Investment or Transfer (Transfer = between your own accounts, left out of totals).",
    "A new Category name gets its own column on the Summary sheet automatically.",
    "Your name, family members and investment account are set in the app's Settings, not here.",
    "Categories are re-applied on every import, except rows whose Category you changed by hand on Transactions.",
]
RULES_MARKER = "budget-tracker-rules-v2"      # hidden cell Z1: Rules sheet holds only your rules

# Keywords that earlier versions wrote into the Rules sheet (removed when an old file is upgraded)
BUILTIN_CATS = {c.lower(): c for _, c, _ in DEFAULT_RULES}
BUILTIN_CATS.update({"to family": "To family", "other": "Other"})

LEGACY_KEYWORDS = ["Karolis Vitulskas", "taupym", "savings", "vault", "cashback", "palūkan", "interest",
                   "YOUR_SAVINGS_IBAN_1", "YOUR_SAVINGS_IBAN_2", "YOUR_THING_ACCOUNT_IBAN",
                   "YOUR_DOWNPAYMENT_ACCOUNT_IBAN", "YOUR_HOLIDAY_ACCOUNT_IBAN",
                   "FAMILY_MEMBER_NAME_1", "FAMILY_MEMBER_NAME_2"]

# --------------------------------------------------------------------------
# Text helpers
# --------------------------------------------------------------------------


def fold(s):
    """Lowercase + strip accents, keeping exactly one output char per input char."""
    out = []
    for ch in s:
        base = "".join(c for c in unicodedata.normalize("NFKD", ch)
                       if not unicodedata.combining(c))
        out.append((base[:1] or ch).lower()[:1])
    return "".join(out)


def norm(s):
    """Normalized text used for keyword matching (cached: the same descriptions are matched again and again)."""
    return _norm(str(s or ""))


@lru_cache(maxsize=65536)
def _norm(s):
    return re.sub(r"[^a-z0-9]+", " ", fold(s)).strip()


def kw_pattern(keyword, whole=False):
    """Keyword -> regex on norm()'d text. Matches at the start of a word; the keyword's own
    words may be joined or spaced ("circle k" = "circlek"), digit groups too (IBANs), but a
    word is never split ("iki" does not match "i kita"). whole=True: also ends at a word end,
    unless the keyword ends with * ("bolt" does not match "Bolton", "kavin*" matches "kavinė")."""
    stem = str(keyword or "").rstrip().endswith("*")
    words = norm(keyword).split()
    if not words:
        return None

    def word_rx(w):
        out = []
        for i, ch in enumerate(w):
            if i and ch.isdigit() and w[i - 1].isdigit():
                out.append(r"\s*")
            out.append(re.escape(ch))
        return "".join(out)

    end = r"(?![a-z0-9])" if whole and not stem else ""
    return re.compile(r"(?<![a-z0-9])" + r"\s*".join(word_rx(w) for w in words) + end)


def rule_matches(keyword, txns):
    """Transactions whose description contains the keyword (as a rule would match it)."""
    pat = kw_pattern(keyword)
    return [t for t in txns if pat and pat.search(norm(t["desc"]))] if pat else []


def to_float(num):
    s = re.sub(r"[   ']", "", num)
    return float(re.sub(r"[.,]", "", s[:-3]) + "." + s[-2:])

PLACE_NOISE = re.compile(
    r"(?<![a-z0-9])(mokejimo kortele|mokejimas kortele|kortele|korteles|mokejimas|card payment|card|payment|"
    r"purchase|pirkinys|apmokejimas|to|from|uab|ab|mb|ii|vsi|lt|ltd|sia|oy|gmbh)(?![a-z0-9])")


def clean_place(text):
    """Short merchant / place name from a description line."""
    t = re.sub(r"\S*\*+\S*", " ", str(text or ""))                          # masked card numbers
    t = re.sub(r"\b[A-Z]{2}\d{2}(?:\s?[A-Z0-9]{4}){3,}\b", " ", t)           # IBANs
    t = re.sub(r"\d{4}[-.]\d{2}[-.]\d{2}|\b\d{1,2}:\d{2}(?::\d{2})?\b|\b\d{5,}\b", " ", t)
    f, chars = fold(t), list(t)
    for m in PLACE_NOISE.finditer(f):
        for i in range(m.start(), m.end()):
            chars[i] = " "
    t = re.sub(r"[\s,;:|/\\]+", " ", "".join(chars))
    t = re.sub(r"[*?~]", "", t).strip(" .-'\"").lstrip("=<>+ ")
    t = " ".join(t.split()[:3])[:40]
    if fold(t) in ("eur", "usd", "gbp", "pln", ""):        # e.g. Revolut "To EUR": keep it whole
        t = " ".join(str(text or "").split()[:3])[:40]
    if t.isupper():
        t = t.title()
    return t or "Unknown"


# --------------------------------------------------------------------------
# Who the money went to (or came from): the name shown for each payment
# --------------------------------------------------------------------------
LEGAL_WORDS = {"uab", "ab", "mb", "ii", "vsi", "ltd", "limited", "sia", "oy", "oyj", "gmbh", "as", "plc", "inc", "llc",
               "bv", "sa", "srl", "spa", "kb", "zub", "tub"}
COUNTRY_CODES = {"lt", "ltu", "lv", "lva", "ee", "est", "fi", "fin", "gb", "gbr", "uk", "de", "deu", "pl", "pol", "se",
                 "swe", "nl", "nld", "ie", "irl", "lux", "fr", "fra", "es", "esp", "it", "ita", "gr", "grc", "cz", "cze",
                 "us", "usa", "ku", "vl"}
CURRENCY_CODES = {"eur", "usd", "gbp", "pln", "sek", "nok", "dkk", "chf", "czk", "huf", "jpy"}
PAY_SERVICES = {"paysera", "opay", "paypal", "sumup", "stripe", "montonio", "neopay", "kevin", "makecommerce", "sq",
                "mkk", "vfi"}
NAME_STOP = {"pavedimas", "sent", "mokejimas", "uz", "transfer", "withdrawal", "from", "to", "for", "payment",
             "reference", "du", "saskaita", "imoka", "grazinimas", "uzsakymo", "uzsakymas", "pagal"}
# a bank's own charges: (words in the description, what it is)
BANK_FEES = [(re.compile(r"kortel\w*\s.*(mokest|isdav)|card\s+(fee|delivery)"), "card fee"),
             (re.compile(r"banko\s+mokest|ikainis|pavedimo\s+mokest|transfer\s+fee"), "transfer fee"),
             (re.compile(r"paslaugu\s+mokest|aptarnavimo\s+mokest|plano\s+mokest|saskaitos\s+mokest|plan\s+fee"),
              "account fee")]
PURCHASE_LEAD = re.compile(r"(?:pirkinys|mokejimas kortele|mokejimo kortele|mokejimas|card payment|purchase|"
                           r"apmokejimas)\b[\s:,-]*")
ADDRESS_RE = re.compile(r"\b(?:g|pl|pr|al|kel|str)\.?\s*\d+\w?\b|\b\d+\w?\s+(?:street|st|road|rd|ave)\b")
FIXED_NAMES = [(re.compile(r"cma\s*freedom|freedom finance"), "Freedom Finance"),
               (re.compile(r"interactive brokers"), "Interactive Brokers")]


def fold_keep_case(s):
    """Accents off, capitals kept, one char per char (so positions match the original)."""
    return "".join((unicodedata.normalize("NFKD", ch)[:1] or ch) for ch in s)


def tidy_name(text):
    """'UAB "NETTA SOLUTIONS"' -> 'Netta Solutions'; 'Paypal *ebay Uk' -> 'Ebay Uk'; 'Paysera LT' -> 'Paysera'."""
    t = re.sub(r"\S*\*{2,}\S*", " ", str(text or ""))                       # masked card numbers
    t = re.sub(r"^(?:www\.)", "", t.strip(), flags=re.I)
    t = re.sub(r"/\*.*$", "", t)                                            # 'www.1global.com/*London'
    t = re.sub(r"^(?:paypal|sumup|sq|mkk|vfi)\s*\*\s*", "", t, flags=re.I)  # payment service in front of the shop
    t = re.sub(r"\(\w{0,3}$", "", t)                                        # cut-off '(p'
    t = re.sub(r"[\"“”„]+", " ", t).replace("*", " ")
    words = [w.strip("'‘’") for w in t.split() if fold(w).strip(".,") not in LEGAL_WORDS
             and not re.fullmatch(r"(?=\w*\d)(?=\w*[A-Za-z])\w{6,}", w)]           # terminal / order codes
    words = [w for w in words if w]
    while len(words) > 1 and fold(words[-1]).strip(".,") in COUNTRY_CODES | CURRENCY_CODES:
        words.pop()
    t = " ".join(words).strip(" ,.;:-/")
    if t and (t.isupper() or t.islower()) and not re.search(r"\.\w{2,3}$", t):
        t = t.title()
    if len(t) > 40:
        t = t[:41].rsplit(" ", 1)[0]
    return t


def _caps_name(desc):
    """Swedbank puts the other side's name first, in capitals, sometimes split over lines:
    'KAUNO TECHNOLOGIJOS Už sąskaitą ... UNIVERSITETAS' -> 'Kauno Technologijos Universitetas'."""
    toks = str(desc).replace('"', " ").split()
    lead = [w for w in toks[:3] if fold(w).strip(".,") not in LEGAL_WORDS | CURRENCY_CODES]
    if not lead or not (lead[0].isupper() and len(re.sub(r"\W", "", lead[0])) >= 2) or re.search(r"\d", lead[0]) \
            and not re.fullmatch(r"[A-Z]+\d+", lead[0]):
        return ""
    out = []
    for i, w in enumerate(toks):
        bare = w.strip(".,;:()")
        f = fold(bare)
        if not bare or f in LEGAL_WORDS or (not out and f in CURRENCY_CODES):
            continue
        if f == "prie" and out:                      # 'INSPEKCIJA PRIE ... MINISTERIJOS': the name ends here
            break
        if bare.isupper() and len(bare) >= 2 and f not in NAME_STOP | COUNTRY_CODES | CURRENCY_CODES \
                and (not re.search(r"\d", bare) or (not out and re.fullmatch(r"[A-Z]+\d+", bare))) \
                and (len(bare) > 3 or not out):
            out.append(bare)
            if len(out) == 5:
                break
        elif not out:
            return ""
    return " ".join(out)


def receiver(desc, bank=""):
    """The shop, company or person on the other side of a payment, found by key words in the description
    (not just its first words, which can be an address or a payment service)."""
    d = re.sub(r"\s+", " ", str(desc or "")).strip()
    f = fold(d)
    for rx, kind in BANK_FEES:
        if rx.search(f) and not re.search(r"\bto:", f):
            return f"{bank} {kind}" if bank else kind.capitalize()
    for rx, name in FIXED_NAMES:
        if rx.search(f):
            return name
    m = re.search(r"pardav\w*\s*:\s*([^)\n,]+)", d, re.I)            # seller behind Paysera & co.
    if m and tidy_name(m.group(1)):
        return tidy_name(m.group(1))
    m = re.match(r"(?:Transfer|Payment) (?:from|to) (.+?)(?=\s+(?:Reference|From|To):|$)", d)
    if m:
        name = re.sub(r"\s+(?:Purchase|Sale) of .*$", "", m.group(1))
        return tidy_name(name) or d[:40]
    m = re.match(r"Cash withdrawal at (.+?)(?=\s+(?:To|Fee|Non-Revolut fee):|$)", d)
    if m:
        return " ".join(["ATM"] + [w for w in tidy_name(m.group(1)).split() if fold(w) != "atm"])
    m = re.match(r"Exchanged to ([A-Z]{3})\b", d)
    if m:
        return f"Exchanged to {m.group(1)}"
    m = re.match(r"To (.+?)(?=\s+(?:Reference|From|To):|$)", d)
    if m:
        name = tidy_name(m.group(1))
        return d[:40] if fold(name) in CURRENCY_CODES else name or d[:40]     # 'To EUR' = an exchange
    m = re.match(r"(.+?)\s+(?:Fee: .*?)?(?:Revolut Rate .*?)?To:\s*([^,]+)", d)  # card payment: 'Lidl To: Lidl, Kaunas'
    if m:
        shown, to = tidy_name(m.group(1)), tidy_name(m.group(2))
        bad = (not shown or ADDRESS_RE.search(fold(shown)) or fold(shown).split()[0] in PAY_SERVICES)
        return (to if bad and to else shown) or to or d[:40]
    # card purchase texts: 'PIRKINYS 516793******6842 2026.10.05 MAXIMA LT, X-124, Savanorių pr. 1' -> 'Maxima'
    lead = PURCHASE_LEAD.match(fold(d))
    rest = d[lead.end():] if lead else d
    rest = re.sub(r"^(?:\S*\*{2,}\S*|\d{4}[-.]\d{2}[-.]\d{2}|\d{1,2}:\d{2}(?::\d{2})?|[,;\s])+", "", rest)
    name = _caps_name(rest)
    if name:
        return tidy_name(name)
    if lead and rest:
        return clean_place(rest.split(",")[0])
    m = re.match(r"((?:[A-Z][\w'.-]+\s+){1,4}?)(?=(?i:" + "|".join(NAME_STOP) + r")\b)", fold_keep_case(d))
    words = d[:m.end(1)].split() if m else []                 # 'Nelli Vitulskienė Pavedimas' -> the name
    if words and all(w[0].isupper() for w in words) and fold(words[0]) not in NAME_STOP:
        return tidy_name(" ".join(words))
    return clean_place(d)


def rule_keyword(t):
    """What to suggest for a 'payments containing ...' rule: the name if the description contains it."""
    place = str(t.get("place") or "")
    if place and norm(place) and norm(place) in norm(t.get("desc")):
        return place
    words = [w for w in place.split() if len(norm(w)) >= 4 and norm(w) in norm(t.get("desc")).split()]
    return max(words, key=len) if words else clean_place(t.get("desc"))


# --------------------------------------------------------------------------
# PDF parsing
# --------------------------------------------------------------------------

MONTHS = {"jan": 1, "feb": 2, "mar": 3, "apr": 4, "may": 5, "jun": 6, "jul": 7,
          "aug": 8, "sep": 9, "oct": 10, "nov": 11, "dec": 12,
          "sau": 1, "vas": 2, "kov": 3, "bal": 4, "geg": 5, "bir": 6, "lie": 7,
          "rugp": 8, "rugs": 9, "spa": 10, "lap": 11, "gru": 12}

DATE_RES = [
    # numeric dates may follow a row number (Swedbank: "12 2026-10-18 ...")
    (re.compile(r"^\s*(?:\d{1,4}\s+)?(\d{4})[-./](\d{1,2})[-./](\d{1,2})(?!\d)"), "ymd"),
    (re.compile(r"^\s*(?:\d{1,4}\s+)?(\d{1,2})[-./](\d{1,2})[-./](\d{4})(?!\d)"), "dmy"),
    (re.compile(r"^\s*(\d{4})\s*m\.?\s*([a-z]+)\.?\s*(\d{1,2})\s*d\.?"), "ymonthd"),
    (re.compile(r"^\s*(\d{1,2})\s+([a-z]{3,})\.?,?\s+(\d{4})(?!\d)"), "dmonthy"),
    (re.compile(r"^\s*([a-z]{3,})\.?\s+(\d{1,2}),?\s+(\d{4})(?!\d)"), "monthdy"),
]

MONEY_RE = re.compile(
    r"(?<![\w.,/])"
    r"(?P<sign>[-+−–])?\s?"
    r"(?:(?:€|eur)\s?)?"
    r"(?P<sign2>[-+−–])?"
    r"(?P<num>(?:\d{1,3}(?:[   .,']\d{3})+|\d+)[.,]\d{2})"
    r"(?!\d)(?![.,]\d)"
)

HEADER_KEYS = {
    "date": ["date", "data"],
    "out": ["money out", "isleista", "debit", "debetas", "islaidos", "paid out"],
    "in": ["money in", "gauta", "credit", "kreditas", "iplaukos", "paid in"],
    "amount": ["amount", "suma"],
    "balance": ["balance", "likutis"],
    "dk": ["d/k", "d/c"],
}
HEADER_RES = {
    group: [re.compile(r"(?<![a-z])" + r"\s*".join(re.escape(w) for w in k.split()) + r"(?![a-z])")
            for k in keys]
    for group, keys in HEADER_KEYS.items()
}

SECTION_SKIP = re.compile(r"^\s*(reverted|pending|atsauktos|atsaukti|laukiama|laukiancios)\b")
SECTION_RESUME = re.compile(r"^\s*(account transactions|transactions from|saskaitos operacijos|operacijos nuo)")
STOP_RE = re.compile(r"(?<![a-z])(balance|likutis|total|is viso|apyvarta|turnover|page \d|puslapis|"
                     r"opening|closing|pradinis|galutinis|reverted|pending)(?![a-z])")
NOT_TXN_RE = re.compile(r"(?<![a-z])(pradinis likutis|galutinis likutis|opening balance|closing balance|"
                        r"likutis|apyvarta|turnover|is viso|total)(?![a-z])")
CURRENCY_RE = re.compile(r"(?<![a-z])(eur|€)(?![a-z])")
DK_RE = re.compile(r"(?<![a-z0-9])([dkc])(?![a-z0-9])")
MINUS = ("-", "−", "–")


def month_num(word):
    for k in sorted(MONTHS, key=len, reverse=True):
        if word.startswith(k):
            return MONTHS[k]
    return None


def parse_date_prefix(ftext):
    """Return (date, end_index) if the line starts with a date."""
    for rx, kind in DATE_RES:
        m = rx.match(ftext)
        if not m:
            continue
        g = m.groups()
        try:
            if kind == "ymd":
                d = date(int(g[0]), int(g[1]), int(g[2]))
            elif kind == "dmy":
                d = date(int(g[2]), int(g[1]), int(g[0]))
            elif kind == "ymonthd":
                mo = month_num(g[1])
                d = date(int(g[0]), mo, int(g[2])) if mo else None
            elif kind == "dmonthy":
                mo = month_num(g[1])
                d = date(int(g[2]), mo, int(g[0])) if mo else None
            else:
                mo = month_num(g[0])
                d = date(int(g[2]), mo, int(g[1])) if mo else None
        except ValueError:
            d = None
        if d and 2000 <= d.year <= 2100:
            return d, m.end()
    return None


def page_lines(page):
    """Rebuild text lines from characters, keeping x position of every char."""
    try:
        page = page.dedupe_chars()
    except Exception:
        pass
    chars = [c for c in page.chars if (c.get("text") or "").strip()]
    chars.sort(key=lambda c: (c["top"], c["x0"]))
    groups, cur, cur_top = [], [], None
    for c in chars:
        if cur and c["top"] - cur_top > 2.5:
            groups.append(cur)
            cur = []
        if not cur:
            cur_top = c["top"]
        cur.append(c)
    if cur:
        groups.append(cur)

    lines = []
    for g in groups:
        g.sort(key=lambda c: c["x0"])
        text, spans, prev = [], [], None
        for c in g:
            size = float(c.get("size") or 8)
            if prev is not None:
                gap = c["x0"] - prev["x1"]
                if gap > 1.5 * size:          # column gap
                    text.append("\t")
                    spans.append((prev["x1"], c["x0"]))
                elif gap > max(0.8, 0.2 * size):  # word gap
                    text.append(" ")
                    spans.append((prev["x1"], c["x0"]))
            for ch in c["text"]:
                text.append(ch)
                spans.append((c["x0"], c["x1"]))
            prev = c
        t = "".join(text)
        sizes = sorted(float(c.get("size") or 8) for c in g)
        lines.append({"text": t, "fold": fold(t), "spans": spans,
                      "top": g[0]["top"], "size": sizes[len(sizes) // 2]})
    return lines


def header_columns(line):
    """If the line is a table header, return {column: (x0, x1)}."""
    f = line["fold"]
    found = {}
    for group, regexes in HEADER_RES.items():
        for rx in regexes:
            m = rx.search(f)
            if m:
                found[group] = (line["spans"][m.start()][0], line["spans"][m.end() - 1][1])
                break
    if "date" in found and ({"out", "in", "amount"} & found.keys()):
        return found
    return None


def nearest_col(x0, x1, cols, names, tol=45):
    best = None
    for n in names:
        if n not in cols:
            continue
        h0, h1 = cols[n]
        d = min(abs(x1 - h1), abs(x0 - h0), abs((x0 + x1) / 2 - (h0 + h1) / 2))
        if best is None or d < best[0]:
            best = (d, n)
    return best[1] if best and best[0] <= tol else None


def block_to_txn(block, cols):
    lines = block["lines"]
    amt_cols = [n for n in ("out", "in", "amount", "balance") if n in cols]
    removed = [[] for _ in lines]          # char ranges to cut from description
    removed[0].append((0, block["date_end"]))

    amounts = []
    for li, ln in enumerate(lines):
        for m in MONEY_RE.finditer(ln["fold"]):
            if li == 0 and m.start() < block["date_end"]:
                continue
            x0 = ln["spans"][m.start("num")][0]
            x1 = ln["spans"][m.end("num") - 1][1]
            s = (m.group("sign") or m.group("sign2") or "").strip()
            sign = -1 if s in MINUS and s else (1 if s == "+" else 0)
            col = nearest_col(x0, x1, cols, amt_cols) if amt_cols else None
            amounts.append({"val": to_float(m.group("num")), "sign": sign, "col": col})
            if col or not amt_cols:
                removed[li].append((m.start(), m.end()))

    amount, sign_src = None, "column"
    if "out" in cols or "in" in cols:
        outs = [a["val"] for a in amounts if a["col"] == "out"]
        ins = [a["val"] for a in amounts if a["col"] == "in"]
        if outs or ins:
            amount = (ins[0] if ins else 0.0) - (outs[0] if outs else 0.0)
    else:
        if "amount" in cols:
            cands = [a for a in amounts if a["col"] == "amount"]
        else:
            cands = [a for a in amounts if a["col"] != "balance"]
        if cands:
            a = cands[0]
            sign, sign_src = a["sign"], "symbol"
            if sign == 0 and "dk" in cols:
                for li, ln in enumerate(lines):
                    for m in DK_RE.finditer(ln["fold"]):
                        sx0, sx1 = ln["spans"][m.start()]
                        if nearest_col(sx0, sx1, cols, ["dk", "amount", "date"]) == "dk":
                            sign, sign_src = (-1 if m.group(1) == "d" else 1), "dk"
                            removed[li].append((m.start(), m.end()))
                            break
                    if sign:
                        break
            if sign == 0:
                sign, sign_src = -1, "none"
            amount = sign * a["val"]

    if not amount:
        return None

    bal = next((a for a in amounts if a["col"] == "balance"), None)
    balance = None if bal is None else (-bal["val"] if bal["sign"] == -1 else bal["val"])

    # currency codes are dropped only in the amount area (a "Valiuta" column), never
    # inside the description, e.g. Revolut "To EUR Holiday" must stay intact
    amount_x0 = min((cols[n][0] for n in amt_cols + ["dk"] if n in cols), default=None)
    parts = []
    for li, ln in enumerate(lines):
        chars = list(ln["text"])
        for s, e in removed[li]:
            for i in range(s, e):
                chars[i] = " "
        for m in CURRENCY_RE.finditer(ln["fold"]):
            if amount_x0 is None or ln["spans"][m.start()][0] >= amount_x0 - 50:
                for i in range(m.start(), m.end()):
                    chars[i] = " "
        t = re.sub(r"\s+", " ", "".join(chars)).strip(" |-;,")
        if t:
            parts.append(t)
    desc = " ".join(parts)[:250]
    if not desc or NOT_TXN_RE.search(fold(desc)):
        return None
    return {"date": block["date"], "desc": desc, "amount": round(amount, 2),
            "balance": balance, "sign_src": sign_src, "place": clean_place(parts[0])}


def detect_bank(filename, first_page_text):
    t = first_page_text.lower()
    if "revolut bank uab is a" in t or "revolt21" in t:
        return "Revolut"
    if "habalt22" in t or "swedbank" in t:
        return "Swedbank"
    n = filename.lower()
    if "revolut" in n:
        return "Revolut"
    if "swed" in n:
        return "Swedbank"
    m = re.search(r"LT\d{2}(\d{5})\d{11}", re.sub(r"\s", "", first_page_text.upper()))
    if m:
        return {"73000": "Swedbank", "32500": "Revolut"}.get(m.group(1), "Other")
    return "Other"


def parse_columns(pdf):
    """Parser 1: rebuilds table rows from character positions (amount / balance columns)."""
    txns, cols, skip = [], {}, False
    for page in pdf.pages:
        block = None

        def finish(b):
            if b:
                t = block_to_txn(b, cols)
                if t:
                    txns.append(t)

        for ln in page_lines(page):
            f = ln["fold"]
            d = parse_date_prefix(f)
            if d:
                finish(block)
                block = None if skip else {"date": d[0], "date_end": d[1], "lines": [ln]}
                continue
            hdr = header_columns(ln)
            if hdr:
                finish(block)
                block, cols = None, hdr
                continue
            if SECTION_SKIP.search(f):
                finish(block)
                block, skip = None, True
                continue
            if SECTION_RESUME.search(f):
                finish(block)
                block, skip = None, False
                continue
            if block:
                far = ln["top"] - block["lines"][-1]["top"] > 3.0 * ln["size"]
                if far or STOP_RE.search(f):
                    finish(block)
                    block = None
                else:
                    block["lines"].append(ln)
        finish(block)
    return txns


TRAIL_GAP = re.compile(r"[\s€$£]*(?:eur)?[\s€$£]*")


def text_block_to_txn(block):
    """Row from plain text lines: the amount (and balance) are the money values ending a line."""
    lines = block["lines"]
    tail, amount_li = [], None
    for li, raw in enumerate(lines):
        f = fold(raw)
        start = block["date_end"] if li == 0 else 0
        ms = [m for m in MONEY_RE.finditer(f) if m.start() >= start]
        pos, run = len(f), []
        for m in reversed(ms):
            if TRAIL_GAP.fullmatch(f[m.end():pos]):
                run.insert(0, m)
                pos = m.start()
            else:
                break
        if run:
            tail, amount_li = run, li
            break
    if not tail:
        return None
    am = tail[-2] if len(tail) >= 2 else tail[-1]
    bm = tail[-1] if len(tail) >= 2 else None

    def signed(m):
        s = (m.group("sign") or m.group("sign2") or "").strip()
        return (-1 if s in MINUS and s else (1 if s == "+" else 0)), to_float(m.group("num"))

    sign, val = signed(am)
    balance = None
    if bm is not None:
        bs, bv = signed(bm)
        balance = -bv if bs == -1 else bv

    parts = []
    for li, raw in enumerate(lines):
        t = raw
        if li == amount_li:
            t = t[:tail[0].start()]
        if li == 0:
            t = " " * block["date_end"] + t[block["date_end"]:]
        t = re.sub(r"\s+", " ", t).strip(" |-;,")
        if t:
            parts.append(t)
    desc = " ".join(parts)[:250]
    if not desc or NOT_TXN_RE.search(fold(desc)) or not val:
        return None
    return {"date": block["date"], "desc": desc, "amount": round((sign or -1) * val, 2),
            "balance": balance, "sign_src": "symbol" if sign else "none",
            "place": clean_place(parts[0])}


def parse_text(pdf):
    """Parser 2: works on the plain text lines of each page (no positions needed)."""
    txns, skip = [], False
    for page in pdf.pages:
        block = None

        def finish(b):
            if b:
                t = text_block_to_txn(b)
                if t:
                    txns.append(t)

        for raw in (page.extract_text() or "").splitlines():
            f = fold(raw)
            d = parse_date_prefix(f)
            if d:
                finish(block)
                block = None if skip else {"date": d[0], "date_end": d[1], "lines": [raw]}
                continue
            if SECTION_SKIP.search(f):
                finish(block)
                block, skip = None, True
                continue
            if SECTION_RESUME.search(f):
                finish(block)
                block, skip = None, False
                continue
            if block:
                if STOP_RE.search(f) or len(block["lines"]) >= 6:
                    finish(block)
                    block = None
                else:
                    block["lines"].append(raw)
        finish(block)
    return txns


def finalize(txns):
    """Fix signs where possible and check the running balance. Returns (warnings, bad_rows)."""
    warnings = []
    # no +/- marker but a balance column: the balance change tells the direction
    prev = None
    for t in txns:
        if t["sign_src"] == "none" and prev is not None and t["balance"] is not None:
            diff = round(t["balance"] - prev, 2)
            if abs(abs(diff) - abs(t["amount"])) < 0.011:
                t["amount"], t["sign_src"] = diff, "balance"
        prev = t["balance"] if t["balance"] is not None else prev
    # spending marked with "-": unsigned amounts are incoming money
    unsigned = [t for t in txns if t["sign_src"] == "none"]
    if unsigned:
        if any(t["sign_src"] == "symbol" and t["amount"] < 0 for t in txns):
            for t in unsigned:
                t["amount"], t["sign_src"] = abs(t["amount"]), "symbol"
        else:
            for t in unsigned:
                t["note"] = "CHECK: sign assumed (spending)"
            warnings.append(f"{len(unsigned)} amounts had no +/- marker, assumed spending (see Note column)")
    # running balance check
    bad = 0
    pairs = [(t["amount"], t["balance"]) for t in txns if t["balance"] is not None]
    if len(pairs) >= 2:
        asc = sum(1 for i in range(1, len(pairs)) if abs(pairs[i][1] - pairs[i - 1][1] - pairs[i][0]) > 0.011)
        dsc = sum(1 for i in range(1, len(pairs)) if abs(pairs[i - 1][1] - pairs[i][1] - pairs[i - 1][0]) > 0.011)
        bad = min(asc, dsc)
        if bad:
            warnings.append(f"running balance does not match on {bad} rows - check this statement")
    return warnings, bad


# totals the bank prints on the statement (English and Lithuanian wording)
TOTAL_LINES = {
    "opening": re.compile(r"(?<![a-z])(opening balance|pradinis likutis)(?![a-z])"),
    "closing": re.compile(r"(?<![a-z])(closing balance|galutinis likutis)(?![a-z])"),
    "out": re.compile(r"(?<![a-z])(debit turnover|debeto apyvarta)(?![a-z])"),
    "in": re.compile(r"(?<![a-z])(credit turnover|kredito apyvarta)(?![a-z])"),
}


def _money_values(f):
    out = []
    for m in MONEY_RE.finditer(f):
        sign = (m.group("sign") or m.group("sign2") or "").strip()
        out.append(-to_float(m.group("num")) if sign and sign in MINUS else to_float(m.group("num")))
    return out


def statement_totals(text):
    """{opening, closing, out, in} printed on a statement (any of them may be missing), or {}.
    Swedbank: 'Opening balance 2026-10-01 10.42', 'Debit turnover EUR 10 506.75' ...
    Revolut: the 'Balance summary' row 'Account (Current Account) €204.46 €1,205.13 €1,422.48 €421.81'."""
    out, summary = {}, False
    for raw in text.splitlines():
        f = fold(raw)
        vals = _money_values(f)
        if "balance summary" in f:
            summary = True
            continue
        if summary and len(vals) == 4 and re.match(r"\s*(account|total)\b", f):
            if "opening" not in out or f.lstrip().startswith("account"):
                out.update(zip(("opening", "out", "in", "closing"), vals))
            if f.lstrip().startswith("account"):
                summary = False                       # the account's own row, not the total of all products
            continue
        for key, rx in TOTAL_LINES.items():
            if key not in out and vals and rx.search(f):
                out[key] = vals[-1]
    return out


def check_statement(txns, totals):
    """(True = adds up / False = doesn't / None = nothing printed to check against, explanation)."""
    if not totals or not txns:
        return None, ""
    total = round(sum(t["amount"] for t in txns), 2)
    spent = round(-sum(t["amount"] for t in txns if t["amount"] < 0), 2)
    got = round(sum(t["amount"] for t in txns if t["amount"] > 0), 2)
    problems, checked = [], False
    o, c = totals.get("opening"), totals.get("closing")
    if o is not None and c is not None:
        checked = True
        end = round(o + total, 2)
        if abs(end - c) > 0.011:
            problems.append(f"opening {o:,.2f} + payments {total:+,.2f} = {end:,.2f}, but the statement's closing "
                            f"balance is {c:,.2f} ({c - end:+,.2f} not read)")
    for key, mine, word in (("out", spent, "money out"), ("in", got, "money in")):
        if totals.get(key) is not None:
            checked = True
            if abs(abs(totals[key]) - mine) > 0.011:
                problems.append(f"{word} read {mine:,.2f}, the statement says {abs(totals[key]):,.2f}")
    if not checked:
        return None, ""
    return (not problems), "; ".join(problems)


def read_statement(path):
    """{bank, txns, warnings, check: (ok or None, explanation)}. The first reader is kept when its payments add up
    to the totals printed on the statement; otherwise both readers run and the better result wins."""
    path = Path(path)
    with pdfplumber.open(path) as pdf:
        if not pdf.pages:
            return {"bank": "Other", "txns": [], "warnings": ["empty PDF"], "check": (None, "")}
        texts = [p.extract_text() or "" for p in pdf.pages]
        bank = detect_bank(path.name, texts[0])
        totals = statement_totals("\n".join(texts))
        results, errors = [], []
        for rank, parser in enumerate((parse_columns, parse_text)):
            try:
                txns = parser(pdf)
            except Exception as e:  # noqa: BLE001
                errors.append(f"{parser.__name__}: {type(e).__name__}: {e}")
                continue
            if txns:
                warns, bad = finalize(txns)
                ok, why = check_statement(txns, totals)
                results.append(((ok is False, bad, -len(txns), rank), txns, warns, (ok, why)))
                if ok:                                    # verified against the bank's totals: done
                    break
    if not results:
        return {"bank": bank, "txns": [], "warnings": errors, "check": (None, "")}
    _, txns, warnings, check = min(results, key=lambda r: r[0])
    for t in txns:
        t["bank"] = bank
        t["place"] = receiver(t["desc"], bank)
        t["source"] = path.name
        t.setdefault("note", None)
    return {"bank": bank, "txns": txns, "warnings": warnings, "check": check}


def parse_pdf(path):
    """Return (bank, transactions, warnings)."""
    r = read_statement(path)
    return r["bank"], r["txns"], r["warnings"]


def write_debug(pdf_path, out_path, error=""):
    """What the parsers see in a PDF they could not read - for troubleshooting."""
    lines = [f"File: {Path(pdf_path).name}", f"Error: {error or '-'}", ""]
    try:
        with pdfplumber.open(pdf_path) as pdf:
            lines.append(f"Pages: {len(pdf.pages)}, characters on page 1: {len(pdf.pages[0].chars) if pdf.pages else 0}")
            for i, page in enumerate(pdf.pages[:2], 1):
                lines += ["", f"===== page {i}: text =====", page.extract_text() or "(no text)"]
                lines += ["", f"===== page {i}: positioned lines (top | text) ====="]
                for ln in page_lines(page)[:80]:
                    lines.append(f"{ln['top']:7.1f} | {ln['text']!r}")
    except Exception as e:  # noqa: BLE001
        lines.append(f"Could not open: {type(e).__name__}: {e}")
    Path(out_path).write_text("\n".join(lines), encoding="utf-8")


# --------------------------------------------------------------------------
# Excel workbook
# --------------------------------------------------------------------------

ARIAL = Font(name="Arial", size=10)
ARIAL_B = Font(name="Arial", size=10, bold=True)
TITLE = Font(name="Arial", size=14, bold=True)
NOTE = Font(name="Arial", size=9, italic=True, color="595959")
HDR_FONT = Font(name="Arial", size=10, bold=True, color="FFFFFF")
HDR_FILL = PatternFill("solid", fgColor="1F3864")
SEC_FILL = PatternFill("solid", fgColor="D9E1F2")
TOT_FILL = PatternFill("solid", fgColor="F2F2F2")
NUM_FMT = '#,##0.00;-#,##0.00;"-"'
AMT_FMT = '#,##0.00;[Red]-#,##0.00'


def style_header(ws, row, ncols):
    for c in range(1, ncols + 1):
        cell = ws.cell(row, c)
        cell.font, cell.fill = HDR_FONT, HDR_FILL
        cell.alignment = Alignment(horizontal="center", vertical="center")


def normalize_type(v):
    s = str(v or "").strip().lower()
    for t in TYPES:
        if s.startswith(t.lower()[:5]):
            return t
    return "Expense"


def is_header_row(kw, cat):
    return str(kw or "").strip().lower() == "keyword" and str(cat or "").strip().lower() == "category"


def write_rule_rows(ws, rows, old_last=0):
    """Header in row 1, your rules from row 2 (columns A-C only; the help text stays)."""
    for r in range(1, max(old_last, len(rows) + 1) + 1):
        for c in (1, 2, 3):
            ws.cell(r, c).value = None
    for c, v in enumerate(("Keyword", "Category", "Type"), start=1):
        ws.cell(1, c, v)
    style_header(ws, 1, 3)
    for i, (kw, cat, typ) in enumerate(rows):
        for c, v in enumerate((kw, cat, typ), start=1):
            ws.cell(2 + i, c, v).font = ARIAL


def create_rules_sheet(ws, rows=()):
    write_rule_rows(ws, list(rows))
    for i, line in enumerate(RULES_HELP, start=1):
        ws.cell(i, 5, line).font = ARIAL_B if i == 1 else NOTE
    for col, w in zip("ABCDE", [26, 22, 12, 3, 100]):
        ws.column_dimensions[col].width = w
    ws["Z1"] = RULES_MARKER
    ws.column_dimensions["Z"].hidden = True
    ws.freeze_panes = "A2"
    dv = DataValidation(type="list", formula1='"' + ",".join(TYPES) + '"', allow_blank=True)
    ws.add_data_validation(dv)
    dv.add("C2:C1000")


def ensure_rules_sheet(ws):
    """New file: empty 'your rules' sheet. File from an older version: keep only the rows you added.
    Always: header in row 1 and your rules right below it (repairs files where it slipped to row 2)."""
    if ws.max_row <= 1 and not ws.cell(1, 1).value:
        create_rules_sheet(ws)
        return
    if ws["Z1"].value != RULES_MARKER:
        shipped = {norm(k) for k in LEGACY_KEYWORDS} | {norm(k) for k, _, _ in DEFAULT_RULES}
        keep = []
        for row in ws.iter_rows(min_row=1, max_col=3, values_only=True):
            kw, cat, typ = (list(row) + [None, None, None])[:3]
            if kw and cat and not is_header_row(kw, cat) and not str(kw).strip().startswith("<") \
                    and norm(kw) not in shipped:
                keep.append([str(kw).strip(), cat, typ])
        ws.delete_rows(1, ws.max_row + 1)
        ws.data_validations.dataValidation = []
        create_rules_sheet(ws, keep)
        return
    rows, last = [], 0
    for r in range(1, ws.max_row + 1):
        kw, cat, typ = (ws.cell(r, c).value for c in (1, 2, 3))
        if kw in (None, ""):
            if r <= 2:
                continue                       # header may have slipped one row down
            break
        last = r
        if not is_header_row(kw, cat):
            rows.append((kw, cat, typ))
    if ws.cell(1, 1).value != "Keyword" or any(is_header_row(ws.cell(r, 1).value, ws.cell(r, 2).value)
                                                for r in range(2, last + 1)):
        write_rule_rows(ws, rows, last)


# --------------------------------------------------------------------------
# Settings (your name, family, investment account)
# --------------------------------------------------------------------------


def split_items(text):
    return [s.strip() for s in re.split(r"[;,\n]", str(text or "")) if s.strip()]


def name_variants(name):
    """'Karolis Vitulskas' -> ['Karolis Vitulskas', 'Vitulskas Karolis']"""
    words = str(name or "").split()
    if not words:
        return []
    out = [" ".join(words)]
    if len(words) >= 2:
        out.append(" ".join([words[-1]] + words[:-1]))
    return out


def load_settings(path):
    s = json.loads(json.dumps(DEFAULT_SETTINGS))
    try:
        data = json.loads(Path(path).read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return s
    if isinstance(data, dict):
        for k in s:
            if k in data:
                s[k] = data[k]
    if isinstance(s["family"], str):
        s["family"] = [s["family"]]
    if not isinstance(s["sync"], dict):
        s["sync"] = {}
    return s


def save_settings(path, settings):
    Path(path).write_text(json.dumps(settings, indent=2, ensure_ascii=False), encoding="utf-8")


# --------------------------------------------------------------------------
# Rules and categorization
# --------------------------------------------------------------------------


def read_rules(ws, settings):
    """Your rules from the Rules sheet, then the built-in DEFAULT_RULES.

    Returns (rules, type_map, ordered [(category, type)]); rules = [(pattern, category, sign)].
    """
    rules, type_map, order = [], {}, []

    names = dict(BUILTIN_CATS)                 # lower -> one spelling ("health" -> "Health")
    names.update(merged_categories(settings))  # categories you merged -> the one they went into

    def register(cat, typ):
        cat = names.setdefault(cat.lower(), cat)
        if cat.lower() != "other" and cat.lower() not in type_map:
            type_map[cat.lower()] = typ
            order.append((cat, typ))

    def add(keyword, cat, typ, sign=None, whole=False):
        pat = kw_pattern(keyword, whole)
        if sign is None:                       # spending rules don't take income (except refunds)
            sign = {"Expense": -1, "Income": +1}.get(typ)
        if pat:
            cat = names.setdefault(cat.lower(), cat)
            rules.append((pat, cat, sign))
            register(cat, typ)

    source = ws if isinstance(ws, (list, tuple)) else ws.iter_rows(min_row=2, max_col=3, values_only=True)
    user_rows = [tuple((list(r) + [None, None, None])[:3]) for r in source]
    builtin = len(user_rows)
    for i, (kw, cat, typ) in enumerate(user_rows + DEFAULT_RULES):
        if not kw or is_header_row(kw, cat):
            continue
        kw, cat, typ = str(kw).strip(), str(cat or "").strip(), normalize_type(typ)
        key = kw.upper()
        if key == "<INVESTMENT ACCOUNT>":
            for m in split_items(settings.get("investments")):
                add(m, cat or "Investments", "Investment")
        elif key == "<FAMILY>":
            register(cat or "Family", "Income")
            people = [n for item in settings.get("family", []) for n in split_items(item)]
            for person in people:
                for v in name_variants(person):
                    add(v, cat or "Family", "Income", +1)       # money from family
                    add(v, "To family", "Expense", -1)          # money sent to family
        elif key == "<MY NAME>":
            for v in name_variants(settings.get("my_name")):
                add(v, cat or "Internal transfer", typ)
        elif cat:
            add(kw, cat, typ, whole=i >= builtin)
    return rules, type_map, order


def merged_categories(settings):
    """{lower name: category it was merged into}, following chains (A -> B -> C)."""
    raw = {str(k).strip().lower(): str(v).strip() for k, v in ((settings or {}).get("merged") or {}).items()
           if str(k).strip() and str(v).strip()}
    out = {}
    for k in raw:
        target, seen = raw[k], {k}
        while target.lower() in raw and target.lower() not in seen:
            seen.add(target.lower())
            target = raw[target.lower()]
        out[k] = target
    return out


def match_category(rules, desc, amount):
    nd = norm(desc)
    refund = amount > 0 and merchants.is_refund(desc)
    for pat, cat, sign in rules:
        if sign == 1 and amount < 0:
            continue
        if sign == -1 and amount > 0 and not refund:
            continue
        if pat.search(nd):
            return cat
    return "Other"


# --------------------------------------------------------------------------
# Transactions sheet
# --------------------------------------------------------------------------


def to_date(v):
    if isinstance(v, datetime):
        return v.date()
    if isinstance(v, date):
        return v
    if isinstance(v, str):
        d = parse_date_prefix(fold(v))
        return d[0] if d else None
    return None


def read_transactions(ws):
    rows = list(ws.iter_rows(values_only=True))
    if not rows:
        return []
    idx = {str(h).strip(): i for i, h in enumerate(rows[0]) if h}
    old_layout = "Auto category" not in idx       # file from an older version
    out = []

    def get(r, name):
        i = idx.get(name)
        v = r[i] if i is not None and i < len(r) else None
        return str(v).strip() if isinstance(v, str) else v

    for r in rows[1:]:
        d = to_date(get(r, "Date"))
        try:
            amt = float(get(r, "Amount"))
        except (TypeError, ValueError):
            continue
        if d is None:
            continue
        desc = str(get(r, "Description") or "")
        out.append({"date": d, "bank": str(get(r, "Bank") or ""), "desc": desc,
                    "place": get(r, "Place") or clean_place(desc),
                    "amount": round(amt, 2), "category": get(r, "Category") or None,
                    "auto": get(r, "Category" if old_layout else "Auto category") or None,
                    "type": get(r, "Type"),
                    "note": get(r, "Note"), "source": get(r, "Source file")})
    return out


def write_transactions(ws, txns):
    ws.delete_rows(1, ws.max_row + 1)
    ws.auto_filter.ref = None
    ws.append(TX_HEADERS)
    for t in sorted(txns, key=lambda t: (t["date"], t["bank"])):
        ws.append([t["date"], date(t["date"].year, t["date"].month, 1), t["desc"], t["place"],
                   t["amount"], t["category"], t["type"], t.get("note"), t.get("source"),
                   t.get("bank"), t.get("auto")])
    style_header(ws, 1, len(TX_HEADERS))
    for r in range(2, ws.max_row + 1):
        for c in range(1, len(TX_HEADERS) + 1):
            ws.cell(r, c).font = ARIAL
        ws[f"{TXC['Date']}{r}"].number_format = "yyyy-mm-dd"
        ws[f"{TXC['Month']}{r}"].number_format = "yyyy-mm"
        ws[f"{TXC['Amount']}{r}"].number_format = AMT_FMT
    for h, w in zip(TX_HEADERS, [11, 9, 55, 22, 11, 20, 11, 25, 28, 10, 18]):
        ws.column_dimensions[TXC[h]].width = w
    ws.column_dimensions[TXC["Auto category"]].hidden = True
    ws.freeze_panes = "A2"
    ws.auto_filter.ref = f"A1:{get_column_letter(len(TX_HEADERS))}{ws.max_row}"


# --------------------------------------------------------------------------
# Summary sheet - one row per month
# --------------------------------------------------------------------------


def group_columns(typ, pinned, present, rule_cats):
    """Summary columns of one group: pinned + every category that has transactions."""
    rule_names = [c for c, t in rule_cats if t == typ]
    rule_lower = {c.lower() for c in rule_names}
    pinned_lower = {p.lower() for p in pinned}
    used = {k for k in present if k != "other"}
    known = {c.lower(): c for c in rule_names}
    cols = [known.get(p.lower(), p) for p in pinned if p.lower() in known or p.lower() in used]
    cols += [c for c in rule_names if c.lower() in used and c.lower() not in pinned_lower]
    cols += sorted(present[k] for k in used if k not in rule_lower)
    if typ in ("Income", "Expense"):
        cols.append("Other")
    return cols or (pinned[:1] if pinned else [typ])


def spending_note(category, month, places):
    """Hover note for one Summary cell: where the money went, biggest first."""
    rows = sorted(places.values(), key=lambda v: -v[2])
    lines = [f"{category} - {month:%Y-%m}", ""]
    for place, count, spent in rows[:15]:
        lines.append(f"{place}  x{count}:  {spent:,.2f}")
    if len(rows) > 15:
        rest = rows[15:]
        lines.append(f"...{len(rest)} more:  {sum(v[2] for v in rest):,.2f}")
    lines += ["", f"Total:  {sum(v[2] for v in rows):,.2f}"]
    note = Comment("\n".join(lines), "Budget Tracker")
    note.width = 280
    note.height = 18 * len(lines) + 20
    return note


def write_summary(ws, txns, rule_cats):
    for rng in list(ws.merged_cells.ranges):
        ws.unmerge_cells(str(rng))
    ws.delete_rows(1, ws.max_row + 1)
    ws.cell(1, 1, "Budget by month").font = TITLE
    ws.cell(2, 1, "EUR (euro). Expenses, savings and investments are shown as positive amounts. "
                  "Total expenses does NOT include savings or investments. "
                  "Left over = income - expenses - savings - investments (the month's result, not money in the "
                  "bank - that is on the Balances sheet). Transfers between own accounts are left out. "
                  "Hover over an expense to see where the money went.").font = NOTE
    if not txns:
        ws.cell(4, 1, "No transactions yet - drop statement PDFs into the app.").font = ARIAL
        return

    months = sorted({date(t["date"].year, t["date"].month, 1) for t in txns})
    present = defaultdict(dict)
    spent_at = defaultdict(dict)          # (month, category) -> {place: [place, payments, spent]}
    for t in txns:
        present[t["type"]].setdefault(t["category"].lower(), t["category"])
        if t["type"] == "Expense":
            key = (date(t["date"].year, t["date"].month, 1), t["category"].lower())
            slot = spent_at[key].setdefault(t["place"].lower(), [t["place"], 0, 0.0])
            slot[1] += 1
            slot[2] = round(slot[2] - t["amount"], 2)

    A, M, C, T = TXC["Amount"], TXC["Month"], TXC["Category"], TXC["Type"]
    GR, HR = 3, 4                      # group header row, column header row
    first, last = HR + 1, HR + len(months)
    center = Alignment(horizontal="center", vertical="center", wrap_text=True)
    sep = Border(left=Side(style="thin", color="A6A6A6"))
    group_starts = []

    def group_header(start, end, label, colors):
        dark, light = colors
        ws.cell(GR, start, label)
        if end > start:
            ws.merge_cells(start_row=GR, start_column=start, end_row=GR, end_column=end)
        for c in range(start, end + 1):
            g, h = ws.cell(GR, c), ws.cell(HR, c)
            g.fill, g.font = PatternFill("solid", fgColor=dark), HDR_FONT
            g.alignment = Alignment(horizontal="center", vertical="center")
            h.fill, h.font, h.alignment = PatternFill("solid", fgColor=light), ARIAL_B, center
        group_starts.append(start)

    ws.cell(GR, 1, "Month")
    ws.merge_cells(start_row=GR, start_column=1, end_row=HR, end_column=1)
    for r in (GR, HR):
        ws.cell(r, 1).fill, ws.cell(r, 1).font, ws.cell(r, 1).alignment = HDR_FILL, HDR_FONT, center
    for i, m in enumerate(months):
        c = ws.cell(first + i, 1, m)
        c.number_format, c.font, c.alignment = "yyyy-mm", ARIAL_B, Alignment(horizontal="center")

    col, spans = 2, {}
    for typ, label, negate, pinned, colors in GROUPS:
        start = col
        for name in group_columns(typ, pinned, present.get(typ, {}), rule_cats):
            ws.cell(HR, col, name)
            L = get_column_letter(col)
            for r in range(first, last + 1):
                f = (f'SUMIFS(Transactions!${A}:${A},Transactions!${M}:${M},$A{r},'
                     f'Transactions!${C}:${C},{L}${HR},Transactions!${T}:${T},"{typ}")')
                cell = ws.cell(r, col, ("=-" if negate else "=") + f)
                places = spent_at.get((months[r - first], name.lower())) if typ == "Expense" else None
                if places:
                    cell.comment = spending_note(name, months[r - first], places)
            col += 1
        spans[typ] = (get_column_letter(start), get_column_letter(col - 1))
        group_header(start, col - 1, label, colors)

    start, tot = col, {}
    for name, typ in (("Total expenses", "Expense"), ("Total savings", "Savings"),
                      ("Total investments", "Investment")):
        ws.cell(HR, col, name)
        s, e = spans[typ]
        for r in range(first, last + 1):
            ws.cell(r, col, f"=SUM({s}{r}:{e}{r})")
        tot[typ] = get_column_letter(col)
        col += 1
    ws.cell(HR, col, "Left over")
    s, e = spans["Income"]
    for r in range(first, last + 1):
        ws.cell(r, col, f"=SUM({s}{r}:{e}{r})-{tot['Expense']}{r}-{tot['Savings']}{r}-{tot['Investment']}{r}")
    group_header(start, col, "TOTALS", TOTALS_COLORS)
    last_c = col

    tr, ar = last + 1, last + 2
    ws.cell(tr, 1, "Total")
    ws.cell(ar, 1, "Average")
    for c in range(2, last_c + 1):
        L = get_column_letter(c)
        ws.cell(tr, c, f"=SUM({L}{first}:{L}{last})")
        ws.cell(ar, c, f"=AVERAGE({L}{first}:{L}{last})")

    for r in range(first, ar + 1):
        for c in range(2, last_c + 1):
            cell = ws.cell(r, c)
            cell.number_format = NUM_FMT
            cell.font = ARIAL_B if (c >= start or r >= tr) else ARIAL
            if c in group_starts:
                cell.border = sep
    for r in (tr, ar):
        for c in range(1, last_c + 1):
            ws.cell(r, c).fill = TOT_FILL
        ws.cell(r, 1).font = ARIAL_B
    ws.column_dimensions["A"].width = 10
    for c in range(2, last_c + 1):
        ws.column_dimensions[get_column_letter(c)].width = 14
    ws.row_dimensions[HR].height = 30
    ws.freeze_panes = ws.cell(first, 2)


# --------------------------------------------------------------------------
# Compare sheet - a month against the month before and the average (live Excel formulas)
# --------------------------------------------------------------------------
PICK_FILL = PatternFill("solid", fgColor="FFF2CC")       # the month you pick
UP_FILL = PatternFill("solid", fgColor="F8CBAD")         # spent noticeably more
DOWN_FILL = PatternFill("solid", fgColor="C6EFCE")       # spent noticeably less


def write_compare(ws, txns):
    from openpyxl.formatting.rule import FormulaRule
    for rng in list(ws.merged_cells.ranges):
        ws.unmerge_cells(str(rng))
    ws.delete_rows(1, ws.max_row + 1)
    ws.conditional_formatting = type(ws.conditional_formatting)()
    ws.data_validations.dataValidation = []
    ws.cell(1, 1, "Compare months").font = TITLE
    ws.cell(2, 1, "Pick a month in the yellow cell. Spending per category against the calendar month before and "
                  "the average of the up to 3 months before it (months with statements only). Red = at least "
                  "€20 and 20% more, green = at least €20 and 20% less. Change categories on Transactions and "
                  "this updates by itself.").font = NOTE
    months = sorted({month_of(t["date"]) for t in txns})
    if not months:
        ws.cell(4, 1, "No transactions yet.").font = ARIAL
        return
    spent = spending_by_month(txns)
    totals = defaultdict(float)
    for m in spent:
        for c, v in spent[m].items():
            totals[c] += v
    cats = sorted(totals, key=lambda c: (c.lower() == "other", -totals[c]))
    LIST = "Z"                                            # hidden list of months for the drop-down
    for i, m in enumerate(months):
        ws[f"{LIST}{5 + i}"] = m
        ws[f"{LIST}{5 + i}"].number_format = "yyyy-mm"
    ws.column_dimensions[LIST].hidden = True
    lst = f"${LIST}$5:${LIST}${4 + len(months)}"
    A, M, C, T = TXC["Amount"], TXC["Month"], TXC["Category"], TXC["Type"]

    def sumifs(month_crit, cat_cell):
        return (f'-SUMIFS(Transactions!${A}:${A},{month_crit},Transactions!${C}:${C},{cat_cell},'
                f'Transactions!${T}:${T},"Expense")')

    for col, text in ((1, "Month"), (3, "Month before"), (5, "Months in the average")):
        ws.cell(4, col, text).font = ARIAL_B
    pick = ws.cell(4, 2, months[-1])
    pick.number_format, pick.fill, pick.font = "yyyy-mm", PICK_FILL, ARIAL_B
    dv = DataValidation(type="list", formula1=lst, allow_blank=False)
    ws.add_data_validation(dv)
    dv.add("B4")
    ws["D4"] = f'=IF(COUNTIF({lst},EDATE($B$4,-1))>0,EDATE($B$4,-1),"none")'
    ws["D4"].number_format = "yyyy-mm"
    ws["F4"] = f'=COUNTIFS({lst},">="&EDATE($B$4,-3),{lst},"<"&$B$4)'
    HR = 6
    for c, h in enumerate(("Category", "This month", "Month before", "Change", "Average before", "vs average"), 1):
        ws.cell(HR, c, h)
    style_header(ws, HR, 6)
    mcol = f"Transactions!${M}:${M}"
    for i, cat in enumerate(cats):
        r = HR + 1 + i
        ws.cell(r, 1, cat).font = ARIAL
        now = sumifs(mcol + ",$B$4", f"$A{r}")
        before = sumifs(mcol + ",$D$4", f"$A{r}")
        window = sumifs(mcol + ',">="&EDATE($B$4,-3),' + mcol + ',"<"&$B$4', f"$A{r}")
        ws.cell(r, 2, "=" + now)
        ws.cell(r, 3, '=IF($D$4="none","",' + before + ")")
        ws.cell(r, 4, f'=IF(C{r}="","",B{r}-C{r})')
        ws.cell(r, 5, '=IF($F$4=0,"",' + window + "/$F$4)")
        ws.cell(r, 6, f'=IF(E{r}="","",B{r}-E{r})')
        for c in range(2, 7):
            ws.cell(r, c).number_format, ws.cell(r, c).font = NUM_FMT, ARIAL
    first, last = HR + 1, HR + len(cats)
    tr = last + 1
    ws.cell(tr, 1, "Total spending")
    for c, L in ((2, "B"), (3, "C"), (5, "E")):
        ws.cell(tr, c, f'=IF(COUNT({L}{first}:{L}{last})=0,"",SUM({L}{first}:{L}{last}))')
    ws.cell(tr, 4, f'=IF(C{tr}="","",B{tr}-C{tr})')
    ws.cell(tr, 6, f'=IF(E{tr}="","",B{tr}-E{tr})')
    for c in range(1, 7):
        ws.cell(tr, c).fill, ws.cell(tr, c).font = TOT_FILL, ARIAL_B
        if c > 1:
            ws.cell(tr, c).number_format = NUM_FMT
    for col, base in (("D", "C"), ("F", "E")):
        rng = f"{col}{first}:{col}{tr}"
        ws.conditional_formatting.add(rng, FormulaRule(
            formula=[f'AND(ISNUMBER({col}{first}),{col}{first}>=20,{col}{first}>=0.2*{base}{first})'], fill=UP_FILL))
        ws.conditional_formatting.add(rng, FormulaRule(
            formula=[f'AND(ISNUMBER({col}{first}),{col}{first}<=-20,-{col}{first}>=0.2*{base}{first})'],
            fill=DOWN_FILL))
    for col, w in zip("ABCDEF", (24, 13, 13, 12, 15, 12)):
        ws.column_dimensions[col].width = w
    ws.freeze_panes = ws.cell(HR + 1, 2)


# --------------------------------------------------------------------------
# Places sheet - subscriptions and food places per month
# --------------------------------------------------------------------------
CHANGED_FILL = PatternFill("solid", fgColor="FFD966")    # subscription changed (amber)
NEW_FILL = PatternFill("solid", fgColor="9BC2E6")        # new subscription (blue)


def write_places(ws, txns):
    for rng in list(ws.merged_cells.ranges):
        ws.unmerge_cells(str(rng))
    ws.delete_rows(1, ws.max_row + 1)
    ws.cell(1, 1, "Places & subscriptions by month").font = TITLE
    ws.cell(2, 1, "Visits = number of payments; Spent in EUR (refunds reduce it). "
                  "To rename or merge places, edit the Place column on the Transactions sheet. "
                  "Subscriptions: amber = changed since the last charge, blue = new (hover for why).").font = NOTE

    wanted = {c.lower(): c for c, _ in PLACES_CATEGORIES}
    flags = subscription_changes(txns)
    agg = defaultdict(dict)       # (month, category) -> {place lower: [place, spent]}
    for t in txns:
        cat = t["category"].lower()
        if cat in wanted:
            m = date(t["date"].year, t["date"].month, 1)
            slot = agg[(m, cat)].setdefault(t["place"].lower(), [t["place"], 0.0])
            slot[1] -= t["amount"]
    months = sorted({m for m, _ in agg}, reverse=True)
    if not months:
        ws.cell(4, 1, "No subscriptions or food payments yet.").font = ARIAL
        return

    A, M, C, P = TXC["Amount"], TXC["Month"], TXC["Category"], TXC["Place"]
    width = 4 * len(PLACES_CATEGORIES) - 1
    r = 4
    for m in months:
        mc = ws.cell(r, 1, m)
        mc.number_format = "yyyy-mm"
        ws.merge_cells(start_row=r, start_column=1, end_row=r, end_column=width)
        for c in range(1, width + 1):
            ws.cell(r, c).fill, ws.cell(r, c).font = HDR_FILL, HDR_FONT
        mc.alignment = Alignment(horizontal="left", indent=1)
        hr = r + 1
        lists = []
        for k, (cat, color) in enumerate(PLACES_CATEGORIES):
            c0 = 1 + 4 * k
            for j, text in enumerate((cat, "Visits", "Spent")):
                h = ws.cell(hr, c0 + j, text)
                h.fill, h.font = PatternFill("solid", fgColor=color), ARIAL_B
                h.alignment = Alignment(horizontal="left" if j == 0 else "right")
            places = sorted(agg.get((m, cat.lower()), {}).values(), key=lambda v: -v[1])
            PL = get_column_letter(c0)
            marks = {norm(x["place"]): x for x in flags.get(m, [])} if cat.lower() == "subscriptions" else {}
            for i, (place, _) in enumerate(places):
                rr = hr + 1 + i
                ws.cell(rr, c0, place).font = ARIAL
                crit = (f'Transactions!${M}:${M},$A${r},Transactions!${C}:${C},"{cat}",'
                        f'Transactions!${P}:${P},{PL}{rr}')
                v = ws.cell(rr, c0 + 1, f"=COUNTIFS({crit})")
                s = ws.cell(rr, c0 + 2, f"=-SUMIFS(Transactions!${A}:${A},{crit})")
                v.font, s.font, v.number_format, s.number_format = ARIAL, ARIAL, "0", NUM_FMT
                mark = marks.get(norm(place))
                if mark:                                   # changed since the last charge / new
                    s.fill = CHANGED_FILL if mark["kind"] == "changed" else NEW_FILL
                    s.comment = Comment(("Changed since the last charge:\n" if mark["kind"] == "changed"
                                         else "New subscription:\n") + mark["text"], "Budget Tracker")
            lists.append(len(places))
        n = max(lists)
        tr = hr + 1 + n
        for k, (cat, _) in enumerate(PLACES_CATEGORIES):
            c0 = 1 + 4 * k
            ws.cell(tr, c0, "Total")
            for j in (1, 2):
                L = get_column_letter(c0 + j)
                ws.cell(tr, c0 + j, f"=SUM({L}{hr + 1}:{L}{tr - 1})" if n else "=0")
                ws.cell(tr, c0 + j).number_format = "0" if j == 1 else NUM_FMT
            for j in range(3):
                ws.cell(tr, c0 + j).fill, ws.cell(tr, c0 + j).font = TOT_FILL, ARIAL_B
        r = tr + 3
    for k in range(len(PLACES_CATEGORIES)):
        c0 = 1 + 4 * k
        ws.column_dimensions[get_column_letter(c0)].width = 28
        ws.column_dimensions[get_column_letter(c0 + 1)].width = 8
        ws.column_dimensions[get_column_letter(c0 + 2)].width = 12
        if k < len(PLACES_CATEGORIES) - 1:
            ws.column_dimensions[get_column_letter(c0 + 3)].width = 3


# --------------------------------------------------------------------------
# Public entry point (used by the GUI - graphical user interface)
# --------------------------------------------------------------------------


class ReportLocked(Exception):
    """The Excel report is open in another program (usually Excel)."""


def locked_message(report):
    return f"{Path(report).name} is open in Excel. Close it and try again."


def _read_shared_windows(path):
    """Windows: open with every sharing flag (read, write, delete), so a file Excel has open can still be read."""
    import ctypes
    import msvcrt
    from ctypes import wintypes
    k32 = ctypes.WinDLL("kernel32", use_last_error=True)
    k32.CreateFileW.restype = wintypes.HANDLE
    k32.CreateFileW.argtypes = [wintypes.LPCWSTR, wintypes.DWORD, wintypes.DWORD, wintypes.LPVOID,
                                wintypes.DWORD, wintypes.DWORD, wintypes.HANDLE]
    generic_read, share_all, open_existing, normal = 0x80000000, 0x7, 3, 0x80
    h = k32.CreateFileW(str(path), generic_read, share_all, None, open_existing, normal, None)
    if h is None or h == wintypes.HANDLE(-1).value:
        raise ctypes.WinError(ctypes.get_last_error())
    fd = msvcrt.open_osfhandle(h, os.O_RDONLY | getattr(os, "O_BINARY", 0))
    with open(fd, "rb") as f:
        return f.read()


def read_report_bytes(path):
    """The file's bytes, also while it is open in Excel. Raises ReportLocked if nothing can read it."""
    path = Path(path)
    try:
        return path.read_bytes()
    except PermissionError:
        if os.name != "nt":
            raise ReportLocked(locked_message(path)) from None
    try:
        return _read_shared_windows(path)
    except Exception:  # noqa: BLE001 - locked for reading too
        raise ReportLocked(locked_message(path)) from None


def open_workbook(path, read_only=True):
    """Load a workbook from an in-memory copy: works while Excel has the file open and never holds the file."""
    return load_workbook(BytesIO(read_report_bytes(path)), read_only=read_only)


def report_locked(report):
    """True if the report exists but can't be written (open in Excel)."""
    report = Path(report)
    if not report.exists():
        return False
    try:
        with open(report, "a+b"):
            return False
    except PermissionError:
        return True
    except OSError:
        return False


# --------------------------------------------------------------------------
# Taking turns, and writing while Excel has the report open
# --------------------------------------------------------------------------
_TURN = threading.RLock()            # threads of this app
_turn = {"depth": 0, "file": None}   # + a lock file for other processes (the background sync task)


def _lock_path(report):
    """In the temp folder (never synced by OneDrive), one per report - the window and the background task
    run as the same user, so they find the same file."""
    import hashlib
    import tempfile
    key = hashlib.sha1(os.path.normcase(os.path.abspath(str(report))).encode("utf-8")).hexdigest()[:12]
    return Path(tempfile.gettempdir()) / f"budget_tracker_{key}.lock"


def _take_file_lock(path, timeout):
    end = time.monotonic() + timeout
    f = None
    while True:
        try:
            if f is None:
                f = open(path, "a+b")
            f.seek(0)
            if os.name == "nt":
                import msvcrt
                msvcrt.locking(f.fileno(), msvcrt.LK_NBLCK, 1)
            else:
                import fcntl
                fcntl.flock(f.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
            return f
        except OSError:
            if time.monotonic() > end:
                if f is not None:
                    f.close()
                raise ReportLocked("The report is busy with another update - it is tried again in a moment.") from None
            time.sleep(0.2)


def _drop_file_lock(f):
    if f is None:
        return
    try:
        f.seek(0)
        if os.name == "nt":
            import msvcrt
            msvcrt.locking(f.fileno(), msvcrt.LK_UNLCK, 1)
        else:
            import fcntl
            fcntl.flock(f.fileno(), fcntl.LOCK_UN)
    except OSError:
        pass
    f.close()


@contextmanager
def report_turn(report, timeout=180):
    """One writer at a time for this report, across threads and processes. Re-entrant in the same thread."""
    if not _TURN.acquire(timeout=timeout):
        raise ReportLocked("The report is busy with another update - it is tried again in a moment.")
    try:
        if _turn["depth"] == 0:
            _turn["file"] = _take_file_lock(_lock_path(report), timeout)
        _turn["depth"] += 1
        try:
            yield
        finally:
            _turn["depth"] -= 1
            if _turn["depth"] == 0:
                _drop_file_lock(_turn["file"])
                _turn["file"] = None
    finally:
        _TURN.release()


def replace_file(src, dst, tries=15):
    """os.replace, but patient: right after Excel lets go, antivirus / indexer / OneDrive may hold the file briefly."""
    for i in range(tries):
        try:
            os.replace(src, dst)
            return
        except PermissionError:
            if i == tries - 1:
                raise
            time.sleep(0.2)


def excel_can_release():
    """True on Windows with pywin32: the app can then update Budget.xlsx while it is open in Excel."""
    if os.name != "nt":
        return False
    try:
        import pythoncom  # noqa: F401
        import win32com.client  # noqa: F401
        return True
    except ImportError:
        return False


def _find_in_excel(report):
    """(Excel, its workbook for the report) - None, None if no Excel has it; raises ReportLocked if Excel is busy."""
    import win32com.client
    try:
        xl = win32com.client.GetActiveObject("Excel.Application")
    except Exception:  # noqa: BLE001 - no Excel running
        return None, None
    try:
        paths = {os.path.normcase(os.path.abspath(str(report))), os.path.normcase(str(Path(report).resolve()))}
        books = list(xl.Workbooks)
        wb = next((w for w in books if os.path.normcase(str(w.FullName)) in paths), None)
        if wb is None:                        # in a OneDrive folder Excel shows a web address instead of the path
            same = [w for w in books if str(w.FullName).lower().startswith("http")
                    and str(w.Name).lower() == Path(report).name.lower()]
            wb = same[0] if len(same) == 1 else None
        return xl, wb
    except Exception:  # noqa: BLE001 - Excel isn't answering, e.g. a cell is being edited
        raise ReportLocked(f"Excel is busy (a cell being edited?) - {Path(report).name} is updated in a moment.") from None


@contextmanager
def excel_released(report, log=None):
    """Budget.xlsx open in Excel: Excel closes it (it's a report, rebuilt from your data - nothing typed there is
    kept), the new one is written, then Excel opens it again on the same sheet. Raises ReportLocked if that
    isn't possible (e.g. a cell is being edited); the report is then rebuilt later."""
    report = Path(report)
    if not report.exists() or not report_locked(report) or not excel_can_release():
        yield
        return
    import gc
    import pythoncom
    pythoncom.CoInitialize()
    xl = wb = None
    sheet, closed, alerts = None, False, None
    try:
        xl, wb = _find_in_excel(report)
        if wb is None:
            raise ReportLocked(locked_message(report))       # open in another program
        try:
            alerts = xl.DisplayAlerts
            xl.DisplayAlerts = False                         # no "save?" / "file in use" prompts while we hold the turn
            sheet = wb.ActiveSheet.Name
            if not wb.Saved:                                 # typed in Excel and not saved: kept aside
                keep = _backup_name(report, "unsaved_Excel_edits")
                wb.SaveCopyAs(str(keep))
                if log:
                    log(f"   ⚠ {report.name} had unsaved changes in Excel - kept as {BACKUP_DIR}\\{keep.name}. "
                        f"Excel shows a report rebuilt from your data: change things in the app.")
            wb.Close(SaveChanges=False)
            closed = True
        except Exception:  # noqa: BLE001 - Excel busy, e.g. a cell is being edited
            raise ReportLocked(f"Excel is busy (a cell being edited?) - {report.name} is updated in a moment.") from None
        finally:
            wb = None
        for _ in range(50):                                  # Excel lets go of the file
            if not report_locked(report):
                break
            time.sleep(0.1)
        yield
    finally:
        if closed and xl is not None:
            try:
                again = xl.Workbooks.Open(str(report))
                try:
                    again.Worksheets(sheet).Activate()
                except Exception:  # noqa: BLE001
                    pass
                again = None
            except Exception:  # noqa: BLE001 - Excel was closed meanwhile
                pass
        if xl is not None and alerts is not None:
            try:
                xl.DisplayAlerts = alerts
            except Exception:  # noqa: BLE001
                pass
        xl = wb = None                                       # COM objects go before COM does
        gc.collect()
        pythoncom.CoUninitialize()


CASH = "Cash"                      # Bank value of payments you enter by hand


def is_cash(t):
    return str(t.get("bank") or "").strip().lower() == CASH.lower()


def cash_tx(day, desc, amount, category, typ):
    """A cash payment you entered: negative amount = spent, positive = received."""
    desc = " ".join(str(desc or "").split()) or CASH
    return {"date": day, "bank": CASH, "desc": desc, "place": desc, "amount": round(float(amount), 2),
            "category": category or "Other", "type": normalize_type(typ), "note": "Entered by hand",
            "source": None, "auto": None}


def place_key(t):
    return norm(t.get("place") or clean_place(t["desc"]))


def tx_key(t):
    return (t["date"].isoformat(), t["bank"].lower(), round(t["amount"], 2),
            norm(t["desc"]).replace(" ", "")[:50])


# --------------------------------------------------------------------------
# Balances: how much money there is in each account at the end of each month.
# Bank accounts: from the balance printed next to every row of a statement (no input needed).
# Cash, savings, investments: from an amount you enter once (Balances in the app); then every
# payment moves it. Savings and investments = money put in, not market value.
# --------------------------------------------------------------------------
BALANCES_SHEET = "Balances"
EXTRA_ACCOUNTS = ["Cash", "Savings", "Investments"]
BANK_ORDER = ["Swedbank", "Revolut"]
YOU = "you"                                    # 'From' of a balance you entered
KNOWN_HEADER = "Known balances (at the start of the day)"   # a known balance = money at the start of that day


def statement_anchors(txns, source):
    """[(account, date, balance, source)] at the start of a day: before the first row, after the last."""
    rows = [t for t in txns if t.get("balance") is not None]
    if not rows:
        return []
    first, last = rows[0], rows[-1]
    if first["date"] > last["date"]:                # statement listed newest first
        first, last = last, first
    bank = first["bank"]
    return [(bank, first["date"], round(first["balance"] - first["amount"], 2), source),
            (bank, last["date"] + timedelta(days=1), round(last["balance"], 2), source)]


def tracks_cash(anchors):
    return any(a[0] == "Cash" for a in anchors)


def account_flows(t, track_cash):
    """How one payment moves money between your accounts: [(account, change)]."""
    out = []
    if is_cash(t):
        out.append(("Cash", t["amount"]))
    elif t.get("bank"):
        out.append((t["bank"], t["amount"]))
        if track_cash and (t.get("category") or "").lower() == "cash":
            out.append(("Cash", -t["amount"]))                 # ATM: from the bank into your wallet
    if t.get("type") == "Savings":
        out.append(("Savings", -t["amount"]))
    elif t.get("type") == "Investment":
        out.append(("Investments", -t["amount"]))
    return out


def balance_accounts(txns, anchors):
    banks = {t["bank"] for t in txns if t.get("bank") and not is_cash(t)} | \
            {a[0] for a in anchors if a[0] not in EXTRA_ACCOUNTS}
    return sorted(banks, key=lambda b: (BANK_ORDER.index(b) if b in BANK_ORDER else 9, b)) + EXTRA_ACCOUNTS


def balance_months(txns):
    """Every month from the first payment to this month (so 'now' is there after the last statement)."""
    if not txns:
        return []
    first = min(t["date"] for t in txns)
    last = max(max(t["date"] for t in txns), date.today())
    out, m = [], date(first.year, first.month, 1)
    while m <= last:
        out.append(m)
        m = date(m.year + m.month // 12, m.month % 12 + 1, 1)
    return out


def month_end_balances(txns, anchors, months=None):
    """{month (date, 1st): {account: balance or None}} - None = unknown (no balance known yet).
    A known balance is the money at the start of its day; payments on or after that day move it.
    Several known balances for one account (e.g. investment values you update) are fine: the latest
    one before the month end is used, plus the payments after it."""
    track = tracks_cash(anchors)
    flows = defaultdict(list)
    for t in txns:
        for acct, d in account_flows(t, track):
            flows[acct].append((t["date"], d))
    known = defaultdict(list)
    for acct, d, v, _ in anchors:
        known[acct].append((d, v))
    months = months or balance_months(txns)
    out = {}
    for m in months:
        nxt = date(m.year + m.month // 12, m.month % 12 + 1, 1)
        end = nxt - timedelta(days=1)
        row = {}
        for acct in balance_accounts(txns, anchors):
            an = sorted(known.get(acct, []))
            if not an:
                row[acct] = None
                continue
            before = [a for a in an if a[0] <= nxt]
            if not before and acct in EXTRA_ACCOUNTS:     # an amount you entered counts from its date on
                row[acct] = None
                continue
            d0, v0 = before[-1] if before else an[0]       # statements are complete: back from them too
            fl = flows.get(acct, [])
            if d0 <= end:
                v = v0 + sum(x for dt, x in fl if d0 <= dt <= end)
            else:
                v = v0 - sum(x for dt, x in fl if end < dt < d0)
            row[acct] = round(v, 2) + 0.0
        out[m] = row
    return out


def month_flows(txns, anchors):
    """{month: {account: money moved in (+) or out (-) by payments that month}}."""
    track = tracks_cash(anchors)
    out = defaultdict(lambda: defaultdict(float))
    for t in txns:
        m = date(t["date"].year, t["date"].month, 1)
        for acct, d in account_flows(t, track):
            out[m][acct] += d
    return out


def market_moves(balances, flows, accounts=("Investments", "Savings")):
    """{month: {account: change not explained by payments}} - market swings / interest, from the
    values you update. Only for months where the value is known at both ends."""
    out, prev = {}, None
    for m in sorted(balances):
        row = balances[m]
        out[m] = {}
        for a in accounts:
            if prev is not None and row.get(a) is not None and prev.get(a) is not None:
                mv = round(row[a] - prev[a] - flows.get(m, {}).get(a, 0.0), 2) + 0.0
                if abs(mv) >= 0.005:
                    out[m][a] = mv
        prev = row
    return out


def wealth_series(balances):
    """[(month, {account: balance or None}, total or None, change or None)], oldest first.
    The change compares only accounts known in both months, so setting cash doesn't look like a gain."""
    out, prev = [], None
    for m in sorted(balances):
        row = balances[m]
        known = {a: v for a, v in row.items() if v is not None}
        total = round(sum(known.values()), 2) + 0.0 if known else None
        change = None
        if prev is not None:
            common = [a for a in known if prev.get(a) is not None]
            if common:
                change = round(sum(known[a] - prev[a] for a in common), 2) + 0.0
        out.append((m, row, total, change))
        prev = row
    return out


def read_anchors(wb):
    """Known balances from the Balances sheet: [(account, date, balance, from)]."""
    if BALANCES_SHEET not in wb.sheetnames:
        return []
    ws = wb[BALANCES_SHEET]
    spot = None
    for row in ws.iter_rows(min_row=1, max_row=8):
        for c in row:
            if str(c.value or "").strip().lower().startswith("known balances"):
                spot = (c.row, c.column, str(c.value).strip() != KNOWN_HEADER)
    if not spot:
        return []
    out, r = [], spot[0] + 2
    while True:
        acct = ws.cell(r, spot[1]).value
        if acct in (None, ""):
            break
        d = to_date(ws.cell(r, spot[1] + 1).value)
        try:
            v = float(ws.cell(r, spot[1] + 2).value)
        except (TypeError, ValueError):
            v = None
        if d and v is not None:
            src = str(ws.cell(r, spot[1] + 3).value or YOU).strip()
            if spot[2] and src != YOU:                 # written by the first version: end of that day
                d += timedelta(days=1)
            out.append((str(acct).strip(), d, round(v, 2), src))
        r += 1
    return out


def load_anchors(report):
    report = Path(report)
    if not report.exists():
        return []
    wb = open_workbook(report, read_only=False)
    try:
        return read_anchors(wb)
    finally:
        wb.close()


def write_balances(ws, txns, anchors):
    for rng in list(ws.merged_cells.ranges):
        ws.unmerge_cells(str(rng))
    ws.delete_rows(1, ws.max_row + 1)
    ws.cell(1, 1, "Money you have").font = TITLE
    ws.cell(2, 1, "Balance at the end of each month. Bank accounts come from the balances printed on your "
                  "statements; cash, savings and investments from the amounts you entered in the app "
                  "(Balances) - update them there whenever you like, e.g. the investments' value after the "
                  "market moved. Each one counts from the start of its day, with the payments after it. "
                  "Empty = not known yet.").font = NOTE
    accounts = balance_accounts(txns, anchors)
    months = balance_months(txns)
    table = month_end_balances(txns, anchors, months)
    HR = 4
    headers = ["Month"] + accounts + ["Total"]
    for c, h in enumerate(headers, start=1):
        ws.cell(HR, c, h)
    style_header(ws, HR, len(headers))
    for i, m in enumerate(months):
        r = HR + 1 + i
        ws.cell(r, 1, m).number_format = "yyyy-mm"
        ws.cell(r, 1).font = ARIAL_B
        vals = table[m]
        for c, acct in enumerate(accounts, start=2):
            if vals[acct] is not None:
                ws.cell(r, c, vals[acct]).number_format = NUM_FMT
            ws.cell(r, c).font = ARIAL
        known = [v for v in vals.values() if v is not None]
        tc = ws.cell(r, len(headers), round(sum(known), 2) if known else None)
        tc.number_format, tc.font = NUM_FMT, ARIAL_B
    ws.column_dimensions["A"].width = 10
    for c in range(2, len(headers) + 1):
        ws.column_dimensions[get_column_letter(c)].width = 14
    # known balances (what the table is calculated from)
    kc = len(headers) + 2
    ws.cell(3, kc, KNOWN_HEADER).font = ARIAL_B
    for j, h in enumerate(["Account", "Date", "Balance", "From"]):
        ws.cell(HR, kc + j, h)
    for j in range(4):
        cell = ws.cell(HR, kc + j)
        cell.font, cell.fill = HDR_FONT, HDR_FILL
    for i, (acct, d, v, src) in enumerate(sorted(anchors, key=lambda a: (a[0], a[1]))):
        r = HR + 1 + i
        for j, val in enumerate((acct, d, v, src)):
            cell = ws.cell(r, kc + j, val)
            cell.font = ARIAL
        ws.cell(r, kc + 1).number_format = "yyyy-mm-dd"
        ws.cell(r, kc + 2).number_format = NUM_FMT
    for j, w in enumerate((14, 12, 14, 34)):
        ws.column_dimensions[get_column_letter(kc + j)].width = w
    ws.freeze_panes = ws.cell(HR + 1, 2)


# --------------------------------------------------------------------------
# Month-over-month comparison and subscription changes
# --------------------------------------------------------------------------
def month_of(d):
    return date(d.year, d.month, 1)


def add_months(m, k):
    n = m.year * 12 + m.month - 1 + k
    return date(n // 12, n % 12 + 1, 1)


def spending_by_month(txns):
    """{month: {category: spent}} - spending only (refunds reduce it)."""
    out = defaultdict(lambda: defaultdict(float))
    for t in txns:
        if t.get("type") == "Expense":
            out[month_of(t["date"])][t.get("category") or "Other"] -= t["amount"]
    return out


def compare_months(txns, m, spent=None):
    """Spending per category in month m against the calendar month before and the average of the up to 3
    months before (only months that have statements). Returns ({category: {now, before, avg}}, month before or
    None, months in the average). before / avg are None when there is nothing to compare with."""
    spent = spent if spent is not None else spending_by_month(txns)
    have = {month_of(t["date"]) for t in txns}
    pm = add_months(m, -1)
    earlier = sorted(x for x in have if add_months(m, -3) <= x < m)
    cats = set(spent.get(m, {})) | (set(spent.get(pm, {})) if pm in have else set())
    out = {}
    for c in cats:
        out[c] = {"now": round(spent.get(m, {}).get(c, 0.0), 2) + 0.0,
                  "before": round(spent.get(pm, {}).get(c, 0.0), 2) + 0.0 if pm in have else None,
                  "avg": (round(sum(spent.get(x, {}).get(c, 0.0) for x in earlier) / len(earlier), 2) + 0.0
                          if earlier else None)}
    return out, (pm if pm in have else None), len(earlier)


def change_text(now, before):
    """('▲ €12' / '▼ €5' / 'new' / '±€0' / '', 'up' / 'down' / 'same' / '') for a category's change."""
    if before is None:
        return "", ""
    if before < 0.005 and now >= 0.005:
        return "new", "same"
    d = now - before
    if abs(d) < 0.5:
        return "±€0", "same"
    return (f"▲ €{d:,.0f}", "up") if d > 0 else (f"▼ €{-d:,.0f}", "down")


def subscription_changes(txns):
    """{month: [{place, key, kind 'changed' / 'new', text}]}: a subscription is flagged when, against the last
    month it was charged, it was charged more or fewer times or its amount changed (by at least €0.50 and 5%),
    or when it is new (only once there is an earlier month to compare with)."""
    have = sorted({month_of(t["date"]) for t in txns})
    subs = defaultdict(dict)                          # month -> place key -> [name, charges, total]
    for t in txns:
        if (t.get("category") or "").lower() != "subscriptions" or t.get("type") != "Expense":
            continue
        slot = subs[month_of(t["date"])].setdefault(place_key(t), [t.get("place") or clean_place(t["desc"]), 0, 0.0])
        slot[1] += t["amount"] < 0
        slot[2] -= t["amount"]
    out, last = defaultdict(list), {}
    for m in sorted(subs):
        for key, (name, n, total) in sorted(subs[m].items()):
            total = round(total, 2)
            prev = last.get(key)
            if prev:
                pm, pn, pt = prev
                diff = abs(total - pt)
                if n != pn or (diff >= 0.5 and diff >= 0.05 * abs(pt)):
                    out[m].append({"place": name, "key": key, "kind": "changed",
                                   "text": f"{name}: charged {n}× ({total:.2f}); {pm:%b %Y}: {pn}× ({pt:.2f})"})
            elif have and have[0] < m:
                out[m].append({"place": name, "key": key, "kind": "new",
                               "text": f"{name}: new subscription, {n}× ({total:.2f})"})
            last[key] = (m, n, total)
    return out


def month_totals(txns, month):
    s = defaultdict(float)
    for t in txns:
        if (t["date"].year, t["date"].month) == (month.year, month.month):
            s[t["type"]] += t["amount"]
    inc, exp, sav, inv = (round(v, 2) + 0.0 for v in (s["Income"], -s["Expense"], -s["Savings"], -s["Investment"]))
    return inc, exp, sav, inv, round(inc - exp - sav - inv, 2) + 0.0


# --------------------------------------------------------------------------
# Your data: Budget_data.json (the main copy). Budget.xlsx is rebuilt from it.
# --------------------------------------------------------------------------
DATA_SUFFIX = "_data.json"
TX_FIELDS = ("bank", "desc", "place", "amount", "category", "auto", "type", "note", "source")
EXCEL_NOTE = ("This file is a report, rebuilt by Budget Tracker after every change - "
              "change categories, rules and balances in the app (or on the iPhone), not here.")


def store_path(report):
    report = Path(report)
    return report.with_name(report.stem + DATA_SUFFIX)


def _text(v):
    """A cell as text: Excel may have turned a note into a date or a time, or a category into a number."""
    if v is None:
        return None
    if hasattr(v, "isoformat"):
        return v.isoformat()
    v = str(v).strip()
    return v or None


def _tx_out(t):
    d = {k: _text(t.get(k)) for k in TX_FIELDS}
    d["amount"] = round(float(t["amount"]), 2)
    d["date"] = t["date"].isoformat()
    return d


def _tx_in(d):
    t = {k: d.get(k) for k in TX_FIELDS}
    t["date"] = date.fromisoformat(d["date"])
    t["amount"] = round(float(t["amount"]), 2)
    t["bank"], t["desc"] = t["bank"] or "", t["desc"] or ""
    t["place"] = t["place"] or clean_place(t["desc"])
    return t


def rules_from_sheet(ws):
    """Your rules on a Rules sheet (any version of the app): [[keyword, category, type]]."""
    if ws["Z1"].value != RULES_MARKER:                       # first versions mixed in the built-in rules
        shipped = {norm(k) for k in LEGACY_KEYWORDS} | {norm(k) for k, _, _ in DEFAULT_RULES}
        rows = []
        for row in ws.iter_rows(min_row=1, max_col=3, values_only=True):
            kw, cat, typ = (list(row) + [None, None, None])[:3]
            if kw and cat and not is_header_row(kw, cat) and not str(kw).strip().startswith("<") \
                    and norm(kw) not in shipped:
                rows.append([str(kw).strip(), str(cat).strip(), normalize_type(typ)])
        return rows
    rows = []
    for r, row in enumerate(ws.iter_rows(min_row=1, max_col=3, values_only=True), start=1):
        kw, cat, typ = (list(row) + [None, None, None])[:3]
        if kw in (None, ""):
            continue
        if cat and not is_header_row(kw, cat):
            rows.append([str(kw).strip(), str(cat).strip(), normalize_type(typ)])
    return rows


def store_from_workbook(path):
    """Read a Budget.xlsx made by an earlier version (Excel was the storage then)."""
    wb = open_workbook(path, read_only=True)
    try:
        txns = read_transactions(wb["Transactions"]) if "Transactions" in wb.sheetnames else []
        rules = rules_from_sheet(wb["Rules"]) if "Rules" in wb.sheetnames else []
        try:
            anchors = read_anchors(wb)
        except Exception:  # noqa: BLE001
            anchors = []
    finally:
        wb.close()
    txns = [_tx_in(_tx_out(t)) for t in txns]        # plain values, exactly as they will be stored
    return {"txns": txns, "rules": rules, "anchors": anchors, "excel_stale": True}


def _store_from_json(data):
    return {"txns": [_tx_in(d) for d in data.get("txns", [])],
            "rules": [list(r)[:3] for r in data.get("rules", [])],
            "anchors": [(a[0], date.fromisoformat(a[1]), float(a[2]), a[3]) for a in data.get("anchors", [])],
            "excel_stale": bool(data.get("excel_stale")), "excel_mtime": data.get("excel_mtime")}


def _read_json_store(path):
    return _store_from_json(json.loads(Path(path).read_text(encoding="utf-8")))


def _recover_store(report):
    """Budget_data.json can't be read (cut off by a power cut?): it is put aside and the newest backup is used."""
    sp = store_path(report)
    folder = Path(report).with_name(BACKUP_DIR)
    folder.mkdir(exist_ok=True)
    try:
        shutil.copy2(sp, folder / f"{sp.stem}-damaged-{datetime.now():%Y-%m-%d_%H%M%S}.json")
    except OSError:
        pass
    for b in sorted(folder.glob(f"{sp.stem}_*.json"), reverse=True):        # newest first (time stamp in the name)
        try:
            store = _read_json_store(b)
        except (OSError, ValueError, KeyError, TypeError):
            continue
        store["excel_stale"] = True
        try:
            save_store(report, store, backup=False)
        except OSError:
            pass
        return store
    raise ValueError(f"{sp.name} is damaged and no backup of it could be read")


def load_store(report):
    """{txns, rules, anchors, excel_stale, excel_mtime}: your data. The first time it is moved over from
    Budget.xlsx (the original is kept in Backups first)."""
    report = Path(report)
    sp = store_path(report)
    if sp.exists():
        try:
            return _read_json_store(sp)
        except (ValueError, KeyError, TypeError):            # damaged file
            with report_turn(report, timeout=30):
                try:
                    return _read_json_store(sp)              # fixed by another process meanwhile?
                except (ValueError, KeyError, TypeError):
                    return _recover_store(report)
    if report.suffix.lower() == ".json" and report.exists():     # a data backup
        return _read_json_store(report)
    if report.exists():                                          # an earlier version's Budget.xlsx
        with report_turn(report, timeout=30):
            if sp.exists():                                      # moved over by another process just now
                return _read_json_store(sp)
            folder = report.with_name(BACKUP_DIR)
            folder.mkdir(exist_ok=True)
            keep = folder / f"{report.stem}_before_data_file.xlsx"
            if not keep.exists():                                # must work before Budget.xlsx becomes a report
                keep.write_bytes(read_report_bytes(report))
            store = store_from_workbook(report)
            try:
                save_store(report, store, backup=False)
            except OSError:
                pass                                             # moved over again next time
            return store
    return {"txns": [], "rules": [], "anchors": [], "excel_stale": False}


def save_store(report, store, backup=True):
    """Save atomically (a crash can't leave half a file); the previous version goes to the Backups folder."""
    sp = store_path(report)
    sp.parent.mkdir(parents=True, exist_ok=True)
    if backup and sp.exists():
        try:
            make_backup(report)
        except OSError:
            pass
    data = {"v": 1, "saved": datetime.now().isoformat(timespec="seconds"),
            "txns": [_tx_out(t) for t in sorted(store["txns"], key=lambda t: (t["date"], t.get("bank") or ""))],
            "rules": [list(r)[:3] for r in store.get("rules", [])],
            "anchors": [[a[0], a[1].isoformat(), a[2], a[3]] for a in store.get("anchors", [])],
            "excel_stale": bool(store.get("excel_stale")), "excel_mtime": store.get("excel_mtime")}
    tmp = sp.with_name(f"{sp.name}.{os.getpid()}-{threading.get_ident()}.saving")
    try:
        with open(tmp, "w", encoding="utf-8") as f:
            f.write(json.dumps(data, ensure_ascii=False, indent=0))
            f.flush()
            os.fsync(f.fileno())                     # really on disk before it replaces the old file
        replace_file(tmp, sp)
    finally:
        if tmp.exists():
            try:
                tmp.unlink()
            except OSError:
                pass


def load_transactions(report):
    """All transactions (from your data; a .xlsx without data next to it is read directly - old backups)."""
    report = Path(report)
    if report.suffix.lower() == ".xlsx" and not store_path(report).exists() and report.exists() \
            and report.parent.name == BACKUP_DIR:
        return store_from_workbook(report)["txns"]
    return load_store(report)["txns"]


def load_anchors(report):
    return load_store(report)["anchors"]


def read_report(report, settings=None):
    """Everything the app shows: {txns, anchors, categories, excel_stale}."""
    store = load_store(report)
    cats = _categories_from(store["rules"], settings or DEFAULT_SETTINGS, store["txns"])
    return {"txns": store["txns"], "anchors": store["anchors"], "categories": cats,
            "rules": store["rules"], "excel_stale": store.get("excel_stale", False)}


def make_backup(report):
    """Copy your data into the Backups folder (keeps the newest KEEP_BACKUPS)."""
    sp = store_path(report)
    if not sp.exists():
        return None
    folder = Path(report).with_name(BACKUP_DIR)
    folder.mkdir(exist_ok=True)
    stamp = datetime.now().strftime("%Y-%m-%d_%H%M%S")
    dst, n = folder / f"{sp.stem}_{stamp}.json", 1
    while dst.exists():                          # several saves within one second
        n += 1
        dst = folder / f"{sp.stem}_{stamp}_{n}.json"
    shutil.copy2(sp, dst)
    for old in sorted(folder.glob(f"{sp.stem}_*.json"))[:-KEEP_BACKUPS]:
        try:
            old.unlink()
        except OSError:
            pass
    return dst


def save_report(wb, report):
    """Save the Excel report atomically: a crash can't leave a half-written file."""
    report = Path(report)
    report.parent.mkdir(parents=True, exist_ok=True)
    tmp = report.with_name(report.stem + ".saving.xlsx")
    try:
        wb.save(tmp)
        replace_file(tmp, report)
    finally:
        if tmp.exists():
            try:
                tmp.unlink()
            except OSError:
                pass


def list_backups(report):
    """Backups of your data, newest first: [{path, time, count}] (count = transactions). Excel backups made by
    earlier versions are listed too - restoring one moves its data over."""
    report = Path(report)
    folder = report.with_name(BACKUP_DIR)
    files = list(folder.glob(f"{store_path(report).stem}_*.json")) + list(folder.glob(f"{report.stem}_*.xlsx"))
    legacy = report.with_name(BACKUP_NAME)
    if legacy.exists():
        files.append(legacy)
    out = []
    for f in files:
        try:
            if f.suffix.lower() == ".json":
                count = len(json.loads(f.read_text(encoding="utf-8")).get("txns", []))
            else:
                wb = open_workbook(f, read_only=True)
                try:
                    ws = wb["Transactions"] if "Transactions" in wb.sheetnames else None
                    count = max((ws.max_row or 1) - 1, 0) if ws is not None else 0
                finally:
                    wb.close()
        except Exception:  # noqa: BLE001 - unreadable backup
            count = -1
        out.append({"path": f, "time": datetime.fromtimestamp(f.stat().st_mtime), "count": count})
    return sorted(out, key=lambda b: b["time"], reverse=True)


def restore_backup(report, backup, settings=None, timeout=180):
    """Put a backup back as your data (the current data is backed up first) and rebuild the report."""
    backup = Path(backup)
    with report_turn(report, timeout=timeout):
        if backup.suffix.lower() == ".json":
            store = _read_json_store(backup)
        else:
            store = store_from_workbook(backup)
        store["excel_stale"] = True
        store["excel_mtime"] = (load_store(report) if store_path(report).exists() else {}).get("excel_mtime")
        try:
            save_store(report, store)
        except PermissionError:
            raise ReportLocked(f"{store_path(report).name} is in use by another program - try again.") from None
        try:
            rebuild_excel(report, settings)
        except ReportLocked:
            pass                                         # rebuilt once Excel lets go of it


def list_imports(report):
    """Imported statements per month: [{month, source, bank, count}], newest month first."""
    groups = {}
    for t in load_store(report)["txns"]:
        if not t.get("source"):
            continue                                  # rows you added by hand
        m = date(t["date"].year, t["date"].month, 1)
        g = groups.setdefault((t["source"], m), {"month": m, "source": t["source"], "bank": t["bank"], "count": 0})
        g["count"] += 1
    return sorted(groups.values(), key=lambda g: (g["month"], g["source"].lower()), reverse=True)


def add_user_rule(rows, keyword, category, typ):
    """Add a rule to your rules (or update the one that already has this keyword)."""
    for r in rows:
        if norm(r[0]) == norm(keyword):
            r[1], r[2] = category, normalize_type(typ)
            return
    rows.append([keyword, category, normalize_type(typ)])


def user_rule_rows(ws):
    """Your rules on a Rules sheet: [(row, keyword, category, type)] (old reports)."""
    out, r = [], 2
    while ws.cell(r, 1).value not in (None, ""):
        if not is_header_row(ws.cell(r, 1).value, ws.cell(r, 2).value):
            out.append((r, str(ws.cell(r, 1).value), ws.cell(r, 2).value, ws.cell(r, 3).value))
        r += 1
    return out


def delete_user_rules(rows, keywords):
    gone = {norm(k) for k in keywords}
    keep = [r for r in rows if norm(r[0]) not in gone]
    n = len(rows) - len(keep)
    rows[:] = keep
    return n


def list_user_rules(report):
    """Your rules with how many transactions each one matches: [{keyword, category, type, matches}]."""
    store = load_store(report)
    return [{"keyword": kw, "category": cat, "type": normalize_type(typ),
             "matches": len(rule_matches(kw, store["txns"]))} for kw, cat, typ in store["rules"]]


def known_categories(report, settings=None):
    """[(category, type)] for the category picker: your rules, built-in rules and categories in use."""
    store = load_store(report)
    return _categories_from(store["rules"], settings or DEFAULT_SETTINGS, store["txns"])


def _categories_from(rule_rows, settings, txns):
    _, _, order = read_rules(list(rule_rows), settings)
    cats = {c.lower(): (c, t) for c, t in order}
    for t in txns:
        c = (t.get("category") or "").strip()
        if c and c.lower() not in cats and c.lower() != "other":
            typ = t.get("type") if t.get("type") in TYPES else ("Income" if t["amount"] > 0 else "Expense")
            cats[c.lower()] = (c, typ)
    out = sorted(cats.values(), key=lambda ct: (TYPES.index(ct[1]) if ct[1] in TYPES else 9, ct[0].lower()))
    return out + [("Other", None)]


# --------------------------------------------------------------------------
# The Excel report, rebuilt from your data
# --------------------------------------------------------------------------
def _backup_name(report, what):
    folder = Path(report).with_name(BACKUP_DIR)
    folder.mkdir(exist_ok=True)
    return folder / f"{Path(report).stem}_{what}_{datetime.now():%Y-%m-%d_%H%M%S}.xlsx"


def write_excel(report, txns, rule_cats, rule_rows, anchors, known_mtime=None, log=None):
    """Build Budget.xlsx from scratch. Returns its time stamp afterwards (known_mtime next time: if the file
    changed in between, it was saved in Excel - that copy is kept in Backups). Raises ReportLocked if Excel
    can't let go of it right now."""
    wb = Workbook()
    wb.active.title = "Summary"
    for name in ("Compare", BALANCES_SHEET, "Places", "Transactions", "Rules"):
        wb.create_sheet(name)
    write_transactions(wb["Transactions"], txns)
    write_summary(wb["Summary"], txns, rule_cats)
    write_compare(wb["Compare"], txns)
    write_places(wb["Places"], txns)
    write_balances(wb[BALANCES_SHEET], txns, anchors)
    create_rules_sheet(wb["Rules"], rule_rows)
    note = wb["Summary"].cell(2, 1)
    note.value = f"{note.value or ''} {EXCEL_NOTE}".strip()
    wb.active = 0
    report = Path(report)
    try:
        changed = known_mtime is not None and report.exists() and report.stat().st_mtime_ns != known_mtime
    except OSError:
        changed = False
    if changed:                                     # saved in Excel since the app wrote it
        keep = _backup_name(report, "edited_in_Excel")
        try:
            keep.write_bytes(read_report_bytes(report))
            if log:
                log(f"   ⚠ {report.name} was changed in Excel - kept as {BACKUP_DIR}\\{keep.name}. It is a report "
                    f"rebuilt from your data: change things in the app (Restore backup can bring that file back).")
        except (OSError, ReportLocked):
            pass
    with excel_released(report, log):
        try:
            save_report(wb, report)
        except PermissionError:
            raise ReportLocked(locked_message(report)) from None
    return report.stat().st_mtime_ns


def rebuild_excel(report, settings=None, log=None, timeout=180):
    """Write Budget.xlsx again from your data (e.g. it was open in Excel at the last change)."""
    settings = settings or DEFAULT_SETTINGS
    with report_turn(report, timeout=timeout):
        store = load_store(report)
        _, type_map, rule_cats = read_rules(list(store["rules"]), settings)
        if tracks_cash(store["anchors"]):
            rule_cats = [(c, "Transfer" if c.lower() == "cash" else t) for c, t in rule_cats]
        store["excel_mtime"] = write_excel(report, store["txns"], rule_cats, store["rules"], store["anchors"],
                                           store.get("excel_mtime"), log)
        store["excel_stale"] = False
        try:
            save_store(report, store, backup=False)
        except OSError:
            pass


def update_report(pdf_paths, report, *args, **kwargs):
    """See _update_report. Only one update at a time (the window, its sync and the background task take turns).
    Your data is saved first; Budget.xlsx is rebuilt from it (later, if Excel can't let go of it right now)."""
    with report_turn(report):
        return _update_report(pdf_paths, report, *args, **kwargs)


def _update_report(pdf_paths, report, settings=None, log=print, remove=(), edits=(), new_rules=(),
                   delete_rules=(), add_cash=(), delete_cash=(), company_file=None, merge=(), set_balances=(),
                   checks=None, statements=()):
    """Add the transactions of the given statement PDFs to the Excel report.

    With no PDFs it only re-applies rules and settings to the existing report.
    remove = [(source file name, month date)]: those statement rows are taken out first
    (used to delete or replace a month's statement); hand-made edits carry over to
    matching rows of the replacement file.
    edits = [(tx_key, category, type)]: categories changed in the app.
    new_rules = [(keyword, category, type)]: added to (or updated on) the Rules sheet.
    add_cash = [cash_tx(...)]: cash payments you entered (Bank = 'Cash', no source file).
    delete_cash = [tx_key]: cash payments to take out. Statement rows are never deleted this way.
    company_file = companies.tsv: payments no rule knows are guessed from known shops / the company list.
    set_balances = [(account, date, amount or None)]: balances you entered (None = forget yours).
    merge = [(category, into, "merge" or "rename")]: only for the log - the merge itself lives in
    settings['merged'], so your rules, built-in rules and guesses all follow it and Undo is exact.
    checks = a list: each statement's check against its printed totals is added to it
    ({file, bank, count, ok: True / False / None, message}).
    statements = statements already read (on the iPhone): [{name, bank, txns, check: (ok, why)}].
    Creates the report if needed, never duplicates transactions and keeps rows
    whose Category was changed by hand. Returns the number of new transactions.
    Raises ReportLocked if the report is open in Excel.
    """
    report = Path(report)
    settings = settings or DEFAULT_SETTINGS
    pdf_paths = list(pdf_paths)
    store = load_store(report)
    excel_mtime = store.get("excel_mtime")
    if not store["txns"] and not store["anchors"] and not pdf_paths and not statements and not add_cash \
            and not set_balances:
        return 0

    # --- parse statements ---
    parsed, new_anchors = [], []
    for p in map(Path, pdf_paths):
        ok, why = None, ""
        try:
            st = read_statement(p)
            bank, txns, warns, (ok, why) = st["bank"], st["txns"], st["warnings"], st["check"]
            error = "; ".join(warns) if not txns else ""
        except Exception as e:  # noqa: BLE001
            txns, error = [], f"{type(e).__name__}: {e}"
        if not txns:
            dbg = report.with_name(f"{p.stem}_debug.txt")
            write_debug(p, dbg, error)
            log(f"✗ {p.name}: no transactions found{f' ({error})' if error else ''}")
            log(f"   Saved {dbg.name} next to {report.name} - attach it in the chat to get this fixed.")
            continue
        if ok is False:
            log(f"⚠ {p.name}: {bank}, {len(txns)} transactions - they don't add up to the statement: {why}")
        else:
            log(f"✓ {p.name}: {bank}, {len(txns)} transactions"
                + (", checked against the statement's totals" if ok else ""))
        if checks is not None:
            checks.append({"file": p.name, "bank": bank, "count": len(txns), "ok": ok, "message": why})
        for w in warns:
            log(f"   ⚠ {w}")
        parsed.append(txns)
        new_anchors.extend(statement_anchors(txns, p.name))
    for st in statements:                         # read on the iPhone already
        txns, ok, why = st["txns"], st["check"][0], st["check"][1]
        if not txns:
            continue
        if ok is False:
            log(f"⚠ {st['name']}: {st['bank']}, {len(txns)} transactions - they don't add up to the statement: {why}")
        else:
            log(f"✓ {st['name']}: {st['bank']}, {len(txns)} transactions"
                + (", checked against the statement's totals" if ok else ""))
        if checks is not None:
            checks.append({"file": st["name"], "bank": st["bank"], "count": len(txns), "ok": ok, "message": why})
        parsed.append(txns)
        new_anchors.extend(statement_anchors(txns, st["name"]))
    pdf_paths = pdf_paths + [st["name"] for st in statements]
    if pdf_paths and not parsed and not set_balances:
        log("Nothing to add.")
        return 0

    # --- your data ---
    anchors = list(store["anchors"])
    rule_rows = [list(r) for r in store["rules"]]
    deleted_rules = delete_user_rules(rule_rows, delete_rules) if delete_rules else 0
    for keyword, category, typ in new_rules:
        add_user_rule(rule_rows, keyword, category, typ)
    rules, type_map, rule_cats = read_rules(rule_rows, settings)
    existing = [dict(t) for t in store["txns"]]

    # --- known balances: from the statements just read, and the ones you entered ---
    removed_sources = {str(s) for s, _ in remove}
    new_sources = {a[3] for a in new_anchors}
    anchors = [a for a in anchors if a[3] not in removed_sources | new_sources] + new_anchors
    for acct, d, v in set_balances:                # a new day adds a value, the same day replaces it
        anchors = [a for a in anchors if not (a[0] == acct and a[3] == YOU and (d is None or a[1] == d))]
        if v is not None:
            anchors.append((acct, d, round(float(v), 2), YOU))
    if tracks_cash(anchors):                  # cash is an account now: ATM = into your wallet, not spending
        type_map["cash"] = "Transfer"
        rule_cats = [(c, "Transfer" if c.lower() == "cash" else t) for c, t in rule_cats]
    merge_from = {str(m[0]).strip().lower() for m in merge}
    merge_moved = sum(1 for t in existing if (t.get("category") or "").lower() in merge_from)

    # --- categories changed in the app ---
    edit_map = {k: (cat, typ) for k, cat, typ in edits}
    edited = 0
    for t in existing:
        if tx_key(t) in edit_map:
            t["category"], t["type"] = edit_map[tx_key(t)]
            t["_edited"] = True
            edited += 1

    # --- cash payments you deleted (one row per key, statement rows untouched) ---
    cash_gone = []
    if delete_cash:
        want, keep = Counter(delete_cash), []
        for t in existing:
            k = tx_key(t)
            if is_cash(t) and want[k] > 0:
                want[k] -= 1
                cash_gone.append(t)
            else:
                keep.append(t)
        existing = keep

    # --- take out the statements being removed / replaced ---
    remove = {(str(src), m) for src, m in remove}
    removed = []
    if remove:
        keep = []
        for t in existing:
            k = (str(t.get("source")), date(t["date"].year, t["date"].month, 1))
            (removed if k in remove else keep).append(t)
        existing = keep

    # --- merge without duplicates (overlapping statements are handled) ---
    have = Counter(tx_key(t) for t in existing)
    target = {}
    for txns in parsed:
        rows = defaultdict(list)                          # one pass (was a scan of all payments per payment)
        for t in txns:
            rows[tx_key(t)].append(t)
        for k, same in rows.items():
            if len(same) > target.get(k, (0, None))[0]:
                target[k] = (len(same), same)
    new = []
    for k, (n, rows) in target.items():
        extra = n - have.get(k, 0)
        if extra > 0:
            new.extend(rows[:extra])
    if removed and new:                   # replacement file: keep your edits on matching rows
        carry = defaultdict(list)
        for t in removed:
            carry[tx_key(t)].append(t)
        for t in new:
            if carry.get(tx_key(t)):
                old = carry[tx_key(t)].pop(0)
                for k in ("category", "auto", "note", "place"):
                    if old.get(k):
                        t[k] = old[k]
    cash_new = [dict(t) for t in add_cash]
    all_tx = existing + new + cash_new

    # --- categorize: re-applied every time, except categories changed by hand ---
    try:
        companies = merchants.load_index(company_file)
    except Exception as e:  # noqa: BLE001 - a broken company file must not stop the import
        log(f"   ⚠ company list not used: {type(e).__name__}: {e}")
        companies = None
    guessed = 0
    for t in all_tx:
        if is_cash(t):                                # your own text for cash
            t.setdefault("place", clean_place(t["desc"]))
        else:                                         # names improve with the app: always worked out again
            t["place"] = receiver(t["desc"], t.get("bank") or "")
        auto = match_category(rules, t["desc"], t["amount"])
        if str(t.get("note") or "").startswith("Guessed"):
            t["note"] = None                          # re-guessed below if still needed
        if auto == "Other" and not is_cash(t):
            hit = merchants.guess(t["desc"], t["amount"], companies)
            if hit:
                auto = hit[0]
                if not t.get("note"):
                    t["note"] = hit[1]
                t["_guess"] = True
        manual = bool(t.get("category")) and (is_cash(t) or not t.get("auto")
                                               or t["category"].lower() != t["auto"].lower())
        # a payment you changed in the app keeps your category for good: its 'auto' stays what the
        # rules said before, so a rule made at the same time can later be deleted without undoing it
        keep_auto = t.pop("_edited", False) and manual and t.get("auto")
        t["auto"], t["manual"] = (t["auto"] if keep_auto else auto), manual
        if not manual:
            t["category"] = auto
            guessed += bool(t.pop("_guess", False))
        elif t.pop("_guess", False) and str(t.get("note") or "").startswith("Guessed"):
            t["note"] = None                          # you chose the category yourself
    canon = dict(BUILTIN_CATS)
    canon.update({c.lower(): c for c, _ in rule_cats if c.lower() not in canon})
    merged = merged_categories(settings)
    canon.update(merged)                      # merged categories disappear into their target
    for t in all_tx:                          # one spelling per category ("health" -> "Health")
        for k in ("category", "auto"):
            if t.get(k):
                t[k] = canon.setdefault(t[k].lower(), t[k])
    cat_sum = defaultdict(float)
    for t in all_tx:
        cat_sum[t["category"].lower()] += t["amount"]
    for t in all_tx:
        key = t["category"].lower()
        if key == "other":            # one 'Other' column under income, one under expenses
            t["type"] = "Income" if t["amount"] > 0 else "Expense"
        elif key in type_map:
            t["type"] = type_map[key]
        elif t.get("manual") and t.get("type") in TYPES:   # your own category with the type you chose
            pass
        else:                         # unknown category: decided by its net sign
            t["type"] = "Income" if cat_sum[key] > 0 else "Expense"

    # --- save your data, then rebuild the Excel report from it ---
    for t in all_tx:
        t.pop("manual", None)
    store = {"txns": all_tx, "rules": rule_rows, "anchors": anchors, "excel_stale": True, "excel_mtime": excel_mtime}
    try:
        save_store(report, store)
    except PermissionError:
        raise ReportLocked(f"{store_path(report).name} is in use by another program (OneDrive or antivirus?) - "
                           f"it is tried again in a moment.") from None
    try:
        store["excel_mtime"] = write_excel(report, all_tx, rule_cats, rule_rows, anchors, excel_mtime, log)
        store["excel_stale"] = False
        try:
            save_store(report, store, backup=False)
        except OSError:
            pass                                     # the data is saved; the report is merely rebuilt again
    except ReportLocked as e:
        log(f"   ⚠ {report.name} not rebuilt yet: {e} It is rebuilt by itself as soon as it can be - "
            f"your data is saved.")

    if removed:
        log(f"Removed {len(removed)} transactions.")
    if cash_new or cash_gone:
        def one(t):
            return f"{t['desc']} {t['amount']:+,.2f} ({t['category']})"
        if cash_new and cash_gone:
            log(f"Saved cash payment: {', '.join(one(t) for t in cash_new)}.")
        elif cash_new:
            log(f"Saved cash payment{'s' if len(cash_new) > 1 else ''}: {', '.join(one(t) for t in cash_new)}.")
        else:
            log(f"Deleted cash payment{'s' if len(cash_gone) > 1 else ''}: {', '.join(one(t) for t in cash_gone)}.")
    elif pdf_paths:
        log(f"Added {len(new)} new transactions ({len(all_tx)} in total). Saved.")
    elif removed:
        log(f"Saved {report.name} ({len(all_tx)} transactions).")
    elif delete_rules and not (edits or new_rules):
        log(f"Deleted {deleted_rules} rule{'s' if deleted_rules != 1 else ''}. Saved {report.name}.")
    elif edits or new_rules:
        what = f"{edited} payment{'s' if edited != 1 else ''}"
        if new_rules:
            what += " and the rule for " + ", ".join(f"'{k}'" for k, _, _ in new_rules)
        log(f"Category saved: {what}.")
    elif set_balances:
        log("Saved balances: " + ", ".join(f"{a} " + ("removed" if v is None else f"{v:,.2f} on {d:%Y-%m-%d}")
                                            for a, d, v in set_balances) + ".")
    elif merge:
        src, dst, verb = (tuple(merge[0]) + ("merge",))[:3]
        what = f"Renamed {src} to {dst}" if verb == "rename" else f"Merged {src} into {dst}"
        log(f"{what}: {merge_moved} payment{'s' if merge_moved != 1 else ''}.")
    else:
        log(f"Report updated with the new settings ({len(all_tx)} transactions).")
    months = sorted({date(t["date"].year, t["date"].month, 1)
                     for t in (new or cash_new or cash_gone or removed or all_tx)})
    for m in months[-3:]:
        inc, exp, sav, inv, bal = month_totals(all_tx, m)
        log(f"   {m:%Y-%m}  income {inc:,.2f} | expenses {exp:,.2f} | savings {sav:,.2f} | "
            f"investments {inv:,.2f} | left over {bal:,.2f}")
    if new:                                   # subscriptions that changed in the months just imported
        flags = subscription_changes(all_tx)
        hit = [(m, x) for m in sorted({month_of(t["date"]) for t in new}) for x in flags.get(m, [])]
        if hit:
            log(f"Subscriptions that changed ({len(hit)}) - marked on the Places sheet:")
            for m, x in hit:
                log(f"   {m:%Y-%m}  {x['text']}")
    if guessed:
        log(f"Guessed from known shops / company list: {guessed} payment{'s' if guessed != 1 else ''} "
            f"(change any that are wrong under Payments).")
    other = Counter(t["desc"][:60] for t in all_tx if t["category"].lower() == "other")
    if other:
        log(f"Uncategorized ('Other'): {sum(other.values())} - double-click them under Payments to categorize. Most frequent:")
        for d, n in other.most_common(8):
            log(f"   {n} x  {d}")
    return len(new)
