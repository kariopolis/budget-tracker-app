"""Merchant library for Budget Tracker.

Used only for payments that none of your rules or the built-in rules recognise
(they would otherwise land in 'Other'):

1. BRANDS - well-known shops and services: Lithuanian chains and the biggest
   online shops and services in the EU, US and Japan.
2. Lithuanian company list - every company that employs people, from Sodra's
   open data (atvira.sodra.lt). Each company's economic activity code
   (EVRK - Lithuanian version of the EU's NACE classification) gives the
   category, e.g. 56.10 restaurants -> Eating out. Downloaded by the app
   (Settings -> Lithuanian companies) into companies.tsv next to the app.

Guesses are written to the Note column ("Guessed from ...") and are re-made on
every update; a category you choose in the app always wins.
"""

import csv
import io
import os
import re
import tempfile
import unicodedata
import urllib.request
import zipfile
from collections import defaultdict
from datetime import date, datetime
from pathlib import Path


def norm(s):
    """Lowercase, no accents, only letters/digits separated by single spaces."""
    s = unicodedata.normalize("NFKD", str(s or ""))
    s = "".join(c for c in s if not unicodedata.combining(c)).lower()
    return re.sub(r"[^a-z0-9]+", " ", s).strip()


REFUND_RX = re.compile(r"(?<![a-z0-9])(grazin|refund|return|chargeback|revers|kompensac|atsauk|cancel"
                       r"|storn|atgal)")


def is_refund(desc):
    """Money back for something bought (it may go to that spending category, other income may not)."""
    return bool(REFUND_RX.search(norm(desc)))


# --------------------------------------------------------------------------
# 1. Brands. Whole words ("max" never matches "maxima"); a trailing * matches
#    the start of a word ("teatr*" = teatras, teatro ...).
# --------------------------------------------------------------------------
BRANDS = {
    "Market": [
        "express market", "vynoteka", "lastmile", "mesin*", "kaufland", "carrefour", "auchan", "tesco",
        "aldi", "biedronka", "rewe", "edeka", "netto", "spar", "coop", "prisma", "selver", "konzum",
        "mercadona", "albert heijn", "jumbo", "monoprix", "franprix", "intermarche", "leclerc", "penny",
        "billa", "zabka", "walmart", "costco", "whole foods", "trader joe", "safeway", "kroger",
        "publix", "wegmans", "lawson", "familymart", "family mart", "7 eleven", "seven eleven", "aeon",
        "don quijote", "donki", "alepa", "k market", "s market", "r kioski", "booths", "co op",
    ],
    "Eating out": [
        "caffeine", "coffee inn", "huracan", "costa coffee", "starbucks", "pizza jazz", "can can",
        "katpedele", "etno dvaras", "berneliu uzeiga", "grill london", "burger king", "subway",
        "dominos", "domino s", "pizza hut", "papa john", "five guys", "spurgin*", "kepykl*", "cafe",
        "caffe", "bistro", "baras", "gelato", "ledain*", "valgykl*", "uzeig*", "karcem*", "burger*",
        "grill", "ramen", "takeaway", "uber eats", "foodpanda", "glovo", "deliveroo", "just eat",
        "lieferando", "doordash", "grubhub", "pyszne", "mos burger", "yoshinoya", "sukiya", "ichiran",
        "coco ichibanya", "tim hortons", "dunkin", "pret a manger", "vapiano", "bakery", "greet menu", "pub",
    ],
    "Clothes": [
        "uniqlo", "primark", "lpp", "massimo dutti", "stradivarius", "oysho", "vero moda",
        "jack jones", "levis", "levi s", "tommy hilfiger", "calvin klein", "asos", "vinted",
        "boozt", "answear", "aboutyou", "deichmann", "ccc", "ecco", "skechers", "puma", "new balance",
        "reebok", "north face", "columbia", "helly hansen", "denim dream", "apranga", "kappahl", "cubus",
        "dressmann", "takko", "tom tailor", "s oliver", "esprit", "marks spencer", "zozotown",
        "arket", "weekday", "monki", "superdry", "timberland", "converse", "vans",
        "ralph lauren", "hugo boss", "lacoste", "outlet*",
    ],
    "Car": [
        "amic", "lukoil", "skulas", "alausa", "shell", "statoil", "esso", "aral", "omv", "q8",
        "totalenergies", "total energies", "autodoc", "inter cars", "europark", "easypark", "via toll",
        "vignette", "e vinjeta", "autoplius", "technine apziura", "tuvlita", "automobil*",
        "autodali*", "padangu", "tepal*", "bp", "service statio*", "petrol*", "fuel",
        "degalin*", "parkla*", "car park", "carpark",
    ],
    "Transport": [
        "spark", "carguru", "flixbus", "ecolines", "lux express", "kautra", "busturas",
        "vilniaus viesasis transportas", "vvt", "freenow", "free now", "lime", "tier", "taxi", "taksi",
        "trainline", "omio", "deutsche bahn", "pkp intercity", "sncf", "renfe", "trenitalia", "suica",
        "pasmo", "jr east", "jr west", "jr central", "japan rail", "lyft",
    ],
    "Housing & utilities": [
        "vilniaus vandenys", "klaipedos vanduo", "siauliu energija", "silumos tinkl*", "eso",
        "perlas energija", "cgates", "splius", "mezon", "pildyk", "ezys", "esim", "1global", "atliek*", "bendrij*",
        "namu administr*", "komunalin*", "energijos skirstymo", "vandenys",
    ],
    "Health": [
        "manovaistine", "internetine vaistine", "affidea", "anteja", "medicina practica", "kardiolita",
        "northway", "medicum", "synlab", "optik*", "poliklinik*", "ligonin*", "sveikatos centr*",
        "dantu", "masaz*", "vitameda", "sveikatos pazym*", "farmakeio", "pharmac*", "cvs", "walgreens", "matsumoto kiyoshi", "apotheke", "apteka", "pharmacy",
        "farmacia", "dr max",
    ],
    "Sport": [
        "gym", "gym plius", "evolution gym", "fitness", "intersport", "sports direct", "sportsdirect",
        "xxl", "sportisimo", "go sport", "prosport", "velo*", "dviratis", "dviraciu", "zwift", "trainingpeaks", "sporto klub*", "teniso", "golf*",
    ],
    "Shopping": [
        "allegro", "etsy", "bol com", "cdiscount", "otto", "mediamarkt", "media markt", "saturn",
        "fnac", "darty", "rakuten", "mercari", "muji", "daiso", "yodobashi", "bic camera", "joom",
        "banggood", "alibaba", "taobao", "best buy", "newegg", "wayfair", "home depot", "lowes", "macys",
        "nordstrom", "kohls", "tj maxx", "tjmaxx", "marshalls", "zooplus", "kika", "maxi zoo", "douglas",
        "sephora", "rossmann", "dm drogerie", "eurokos", "drogas", "kristiana", "flying tiger", "lego",
        "thomann", "conrad", "alza", "x kom", "morele", "media expert", "galaxus", "digitec", "coolblue",
        "elgiganten", "gigantti", "komplett", "proshop", "home4you", "moki vezi", "depo", "skelbiu",
        "garmin", "samsung", "xiaomi", "huawei", "sony", "dyson", "shopify", "boots", "tokyu hands",
        "whsmith", "relay", "hudson news", "istore", "priedaimobiliems", "parcelhero", "omniva",
        "lp express", "venipak", "dpd", "dhl", "fedex", "paštas", "pastomatas", "dovan*", "geles", "zoo", "avitela", "photopoint", "technorama", "kaina24", "cenuklubas",
    ],
    "Subscriptions": [
        "hbo", "hbo max", "viaplay", "telia play", "tv3 play", "skyshowtime", "paramount", "dazn",
        "crunchyroll", "deezer", "tidal", "audible", "storytel", "bookbeat", "readly", "dropbox", "adobe",
        "canva", "notion", "github", "jetbrains", "figma", "grammarly", "chatgpt", "midjourney",
        "perplexity", "slack", "zoom us", "zoom video", "1password", "lastpass", "bitwarden", "nordvpn",
        "expressvpn", "surfshark", "proton", "evernote", "todoist", "patreon", "twitch", "discord",
        "telegram", "linkedin", "substack", "strava", "headspace", "paddle", "fastspring",
        "delfi", "15min", "lrytas", "icloud", "onedrive", "mega nz",
    ],
    "Travel": [
        "lufthansa", "finnair", "norwegian", "klm", "air france", "turkish airlines", "easyjet", "vueling",
        "transavia", "aegean", "british airways", "emirates", "qatar airways", "japan airlines",
        "lot polish", "polish airlines", "expedia", "hotels com", "agoda", "trivago", "skyscanner",
        "kiwi com", "hostelworld", "trip com", "tripadvisor", "getyourguide", "viator", "novaturas",
        "tez tour", "teztour", "coral travel", "join up", "hilton", "marriott", "radisson", "holiday inn",
        "ibis", "accor", "best western", "scandic", "hostel*", "oro uost*", "airport", "duty free",
        "hertz", "avis", "sixt", "europcar", "rentalcars", "viesbut*", "finavia", "national park",
        "national trust", "english heritage", "embassy", "ambasad*", "uk visas", "vfs global", "ferry*", "tallink", "viking line",
    ],
    "Entertainment": [
        "bilietu pasaulis", "piletilevi", "ticketmaster", "eventim", "kakava", "teatr*", "filharmon*",
        "muziej*", "museum", "akvapark*", "vandens park*", "karting*", "boulingas", "escape room",
        "pabegimo kambar*", "kino", "cinema", "epic games", "gog com", "ubisoft", "blizzard", "nintendo",
        "xbox", "roblox", "riot games", "electronic arts", "humble bundle", "koncert*", "festival*",
        "pramog*", "batut*", "etnografij*", "strike house", "abbey", "castle", "cathedral", "pilis",
    ],
    "Books & education": [
        "vaga", "mint vinetu", "patogu pirkti", "empik", "kindle", "duolingo", "babbel", "edx",
        "datacamp", "skillshare", "masterclass", "linkedin learning", "universitet*", "kolegij*",
        "mokym*", "seminar*", "akademij*", "kursus", "kursai", "kursams", "karjeros centr*", "bookdepository", "book depository", "kinokuniya",
    ],
    "Cash": [
        "forex", "valiutos keityk*", "currency exchange", "travelex",
    ],
    "Insurance": [
        "ergo", "gjensidige", "compensa", "bta", "balcia", "seesam", "if p c",
    ],
}


def _brand_pattern(keyword):
    prefix = keyword.endswith("*")
    words = norm(keyword.rstrip("*")).split()
    if not words:
        return None
    body = r"\s*".join(re.escape(w) for w in words)
    return re.compile(r"(?<![a-z0-9])" + body + ("" if prefix else r"(?![a-z0-9])"))


_BRAND_RULES = None


def brand_rules():
    """[(pattern, category, keyword)] - longer keywords first, so 'hbo max' wins over 'hbo'."""
    global _BRAND_RULES
    if _BRAND_RULES is None:
        items = [(kw, cat) for cat, kws in BRANDS.items() for kw in kws]
        items.sort(key=lambda kc: -len(norm(kc[0])))
        _BRAND_RULES = [(p, cat, kw) for kw, cat in items if (p := _brand_pattern(kw))]
    return _BRAND_RULES


def match_brand(desc):
    nd = norm(desc)
    for pat, cat, kw in brand_rules():
        if pat.search(nd):
            return cat, kw.rstrip("*")
    return None


# --------------------------------------------------------------------------
# 2. Lithuanian companies (Sodra open data) -> category by EVRK code
# --------------------------------------------------------------------------
SODRA_URL = "https://atvira.sodra.lt/imones/downloads/{year}/monthly-{year}.csv.zip"
SODRA_PAGE = "https://atvira.sodra.lt/imones/rinkiniai/index.html"

# EVRK / NACE code prefix (digits only) -> category; the longest matching prefix wins.
EVRK_CATEGORIES = {
    "4711": "Market", "472": "Market", "4781": "Market", "1071": "Market",
    "56": "Eating out",
    "473": "Car", "45": "Car", "5221": "Car",
    "491": "Transport", "4931": "Transport", "4932": "Transport", "4939": "Transport",
    "511": "Travel", "55": "Travel", "79": "Travel", "7711": "Travel",
    "4771": "Clothes", "4772": "Clothes", "4782": "Clothes",
    "4773": "Health", "4774": "Health", "86": "Health",
    "4761": "Books & education", "85": "Books & education",
    "4764": "Sport", "931": "Sport",
    "932": "Entertainment", "90": "Entertainment", "91": "Entertainment", "5914": "Entertainment",
    "35": "Housing & utilities", "36": "Housing & utilities", "38": "Housing & utilities",
    "61": "Housing & utilities", "6820": "Housing & utilities", "6832": "Housing & utilities",
    "65": "Insurance", "6622": "Insurance",
    "4719": "Shopping", "474": "Shopping", "475": "Shopping", "476": "Shopping", "477": "Shopping",
    "4789": "Shopping", "479": "Shopping",
    "60": "Subscriptions",
}

LEGAL_FORMS = {"uab", "ab", "mb", "ii", "vsi", "vs", "zub", "zuk", "kb", "tub", "ku", "sb", "bi", "vi",
               "uzdaroji", "akcine", "bendrove", "mazoji", "individuali", "imone", "viesoji", "istaiga",
               "zemes", "ukio", "kooperatine", "tikroji", "komanditine", "filialas", "atstovybe"}

# One-word company names that also are ordinary words or places in payment texts
STOP_WORDS = {
    "vilnius", "kaunas", "klaipeda", "siauliai", "panevezys", "alytus", "marijampole", "mazeikiai",
    "jonava", "utena", "kedainiai", "telsiai", "taurage", "ukmerge", "visaginas", "plunge", "kretinga",
    "silute", "radviliskis", "palanga", "druskininkai", "birstonas", "elektrenai", "trakai", "neringa",
    "lietuva", "lithuania", "baltic", "baltija", "europe", "europa", "transfer", "payment", "pavedimas",
    "mokejimas", "uzsakymas", "saskaita", "grazinimas", "apmokejimas", "pirkinys", "kortele", "revolut",
    "swedbank", "paysera", "paypal", "card", "reference", "kaunas", "vilniaus", "kauno", "klaipedos",
    "service", "servisas", "centras", "grupe", "group", "prekyba", "sprendimai", "solutions", "projektai",
    "statyba", "transportas", "logistika", "sportas", "kavine", "parduotuve", "market", "shop", "studija",
    "namai", "sodas", "miestas", "pasaulis", "zmones", "draugai", "sveikata", "grozis", "turtas",
    "invest", "investicijos", "finance", "holding", "consulting", "media", "digital", "online", "global",
    "international", "partners", "trade", "travel", "auto", "energy", "energija", "fondas", "bankas",
}


def category_for_evrk(code):
    digits = re.sub(r"\D", "", str(code or ""))
    for n in range(len(digits), 1, -1):
        cat = EVRK_CATEGORIES.get(digits[:n])
        if cat:
            return cat
    return None


def name_tokens(name):
    """Company name -> matching words, without the legal form ('UAB "Kaukita"' -> ('kaukita',))."""
    toks = [t for t in norm(name).split() if t not in LEGAL_FORMS]
    return tuple(toks)


def usable(toks):
    if not toks or all(t.isdigit() for t in toks):
        return False
    if len(toks) == 1:
        return len(toks[0]) >= 5 and toks[0] not in STOP_WORDS
    return sum(len(t) for t in toks) >= 6


def _header_key(h):
    m = re.search(r"\(([^)]*)\)\s*$", str(h or ""))
    return re.sub(r"[^a-z0-9]", "", (m.group(1) if m else str(h or "")).lower())


def _encoding(sample):
    """UTF-8, or the Windows Baltic code page older exports use."""
    try:
        sample.decode("utf-8")
        return "utf-8-sig"
    except UnicodeDecodeError as e:
        return "utf-8-sig" if e.start > len(sample) - 4 else "cp1257"


def read_company_rows(path):
    """Sodra CSV (or the .zip it comes in) -> {company code: (name, EVRK code, month)}."""
    path = Path(path)
    if zipfile.is_zipfile(path):
        with zipfile.ZipFile(path) as z:
            member = next((n for n in z.namelist() if n.lower().endswith(".csv")), None)
            if member is None:
                raise ValueError(f"{path.name}: no .csv file inside")
            with z.open(member) as f:
                enc = _encoding(f.read(1 << 20))
            with z.open(member) as f:
                return _read_rows(io.TextIOWrapper(f, encoding=enc, errors="replace", newline=""))
    with open(path, "rb") as f:
        enc = _encoding(f.read(1 << 20))
    with open(path, encoding=enc, errors="replace", newline="") as text:
        return _read_rows(text)


def _read_rows(text):
    first = text.readline()
    delim = ";" if first.count(";") >= first.count(",") else ","
    headers = next(csv.reader([first], delimiter=delim))
    keys = [_header_key(h) for h in headers]

    def col(*want, avoid=()):
        for i, k in enumerate(keys):
            if any(w == k for w in want) and not any(a in k for a in avoid):
                return i
        for i, k in enumerate(keys):
            if any(w in k for w in want) and not any(a in k for a in avoid):
                return i
        return None

    c_code = col("jarcode", "jarkodas", "code", "kodas", avoid=("ecoact", "evrk", "municip", "savivald"))
    c_name = col("name", "pavadinimas", avoid=("ecoact", "evrk", "municip", "savivald"))
    c_evrk = col("ecoactcode", "evrkkodas", "evrk")
    c_month = col("month", "menuo")
    if c_name is None or c_evrk is None:
        raise ValueError("unexpected columns: " + "; ".join(headers))
    out = {}
    for row in csv.reader(text, delimiter=delim):
        if len(row) <= max(c_name, c_evrk):
            continue
        name, evrk = row[c_name].strip(), row[c_evrk].strip()
        code = row[c_code].strip() if c_code is not None and c_code < len(row) else name
        month = row[c_month].strip() if c_month is not None and c_month < len(row) else ""
        if name and (code not in out or month >= out[code][2]):
            out[code] = (name, evrk, month)
    return out


def build_company_index(source, out_path, source_label=""):
    """Sodra file -> companies.tsv with the companies whose activity maps to a category. Returns the count."""
    rows = read_company_rows(source)
    if not rows:
        raise ValueError("the file has no companies")
    by_tokens = defaultdict(set)
    names = {}
    for name, evrk, _ in rows.values():
        toks = name_tokens(name)
        if usable(toks):                         # every company counts, so a shared name is caught
            cat = category_for_evrk(evrk)
            by_tokens[toks].add(cat)
            if cat:
                names.setdefault(toks, (name, evrk))
    out_path = Path(out_path)
    tmp = out_path.with_suffix(".tmp")
    kept = 0
    with open(tmp, "w", encoding="utf-8", newline="\n") as f:
        f.write(f"# {len(rows)} companies read, {source_label or Path(source).name}, {date.today():%Y-%m-%d}\n")
        for toks, cats in sorted(by_tokens.items()):
            if len(cats) != 1 or None in cats:   # same name, different activities: can't tell
                continue
            name, evrk = names[toks]
            f.write(f"{' '.join(toks)}\t{next(iter(cats))}\t{name}\t{evrk}\n")
            kept += 1
    os.replace(tmp, out_path)
    return kept


def download_company_list(out_path, progress=lambda text: None):
    """Download Sodra's company data (this year's file, or last year's early in January) and index it."""
    errors = []
    year = date.today().year
    for y in (year, year - 1):
        url = SODRA_URL.format(year=y)
        progress(f"Connecting to atvira.sodra.lt ({y})...")
        fd, tmp = tempfile.mkstemp(suffix=".zip")
        os.close(fd)
        try:
            req = urllib.request.Request(url, headers={"User-Agent": "BudgetTracker/1.0"})
            with urllib.request.urlopen(req, timeout=60) as r, open(tmp, "wb") as f:
                total = int(r.headers.get("Content-Length") or 0)
                done = 0
                while chunk := r.read(1 << 16):
                    f.write(chunk)
                    done += len(chunk)
                    of = f" of {total / 1e6:.0f} MB" if total else " MB"
                    progress(f"Downloading company list: {done / 1e6:.1f}{of}")
            if not zipfile.is_zipfile(tmp):
                raise ValueError("the download is not a .zip file")
            progress("Reading companies...")
            return build_company_index(tmp, out_path, source_label=f"Sodra {y}")
        except Exception as e:  # noqa: BLE001 - try last year's file, then report both
            errors.append(f"{url}: {type(e).__name__}: {e}")
        finally:
            try:
                os.remove(tmp)
            except OSError:
                pass
    raise RuntimeError("\n".join(errors))


def company_list_info(path):
    """(companies in the file, date downloaded) or None."""
    path = Path(path)
    if not path.exists():
        return None
    try:
        with open(path, encoding="utf-8") as f:
            first = f.readline()
            n = sum(1 for _ in f)
    except OSError:
        return None
    m = re.search(r"(\d{4}-\d{2}-\d{2})\s*$", first)
    when = datetime.strptime(m.group(1), "%Y-%m-%d").date() if m else \
        date.fromtimestamp(path.stat().st_mtime)
    return n, when


class CompanyIndex:
    """Finds a known company name inside a payment description."""

    def __init__(self, entries):
        self.by_first = defaultdict(list)
        for toks, cat, name, evrk in entries:
            self.by_first[toks[0]].append((toks, cat, name, evrk))

    @classmethod
    def load(cls, path):
        entries = []
        with open(path, encoding="utf-8") as f:
            for line in f:
                if line.startswith("#"):
                    continue
                parts = line.rstrip("\n").split("\t")
                if len(parts) >= 4 and parts[0]:
                    entries.append((tuple(parts[0].split()), parts[1], parts[2], parts[3]))
        return cls(entries)

    def find(self, desc):
        """Longest company name in the merchant part: the text before the first comma, and the
        seller named after 'Pardavėjas:' when paid through Paysera."""
        best = None
        parts = [str(desc).split(",")[0]]
        m = re.search(r"pardav\w*\s*:\s*([^)\n,]+)", str(desc), re.IGNORECASE)
        if m:
            parts.append(m.group(1))
        for part in parts:
            hit = self._find(norm(part).split())
            if hit and (best is None or len(hit[0]) > len(best[0])):
                best = hit
        return best

    def _find(self, toks):
        best = None
        for i, tok in enumerate(toks):
            for entry in self.by_first.get(tok, ()):
                ct = entry[0]
                j = i + len(ct)
                if j > len(toks) or tuple(toks[i:j - 1]) != ct[:-1]:
                    continue
                last = toks[j - 1]
                # card terminals cut names short: 'Kesko Senukai Lithuani'
                if last != ct[-1] and not (j == len(toks) and len(last) >= 4 and ct[-1].startswith(last)
                                           and len(ct) > 1):
                    continue
                if best is None or len(ct) > len(best[0]):
                    best = entry
        return best


_INDEX_CACHE = {}


def load_index(path):
    """CompanyIndex for companies.tsv (cached until the file changes), or None."""
    if not path:
        return None
    path = Path(path)
    try:
        stamp = path.stat().st_mtime_ns
    except OSError:
        return None
    cached = _INDEX_CACHE.get(str(path))
    if cached and cached[0] == stamp:
        return cached[1]
    index = CompanyIndex.load(path)
    _INDEX_CACHE[str(path)] = (stamp, index)
    return index


def guess(desc, amount, index=None):
    """(category, note) for a payment no rule recognised, or None. Money coming in is only
    guessed when it is a refund (a scholarship from a university is not a refund for books)."""
    if amount > 0 and not is_refund(desc):
        return None
    hit = match_brand(desc)
    if hit:
        return hit[0], f"Guessed from known shops: {hit[1]}"
    if index is not None and amount < 0:          # money in from a company is usually pay, not a shop
        found = index.find(desc)
        if found:
            evrk = found[3]
            pretty = f"{evrk[:2]}.{evrk[2:4]}" if re.fullmatch(r"\d{4,6}", evrk) else evrk
            return found[1], f"Guessed from company register: {found[2]} (activity {pretty})"
    return None
